<?php


namespace HybridWoo\Inc;


class install
{
    public function __construct() {
        $this->create_tables();
    }

    /**
     * Install DB and create cron events when activated.
     *
     * @return void
     */
    public static function create_tables() {

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta( self::get_schema() );
    }
    /**
     * Get database schema.
     *
     * @return string
     */
    protected static function get_schema() {
        global $wpdb;

        if ( $wpdb->has_cap( 'collation' ) ) {
            $collate = $wpdb->get_charset_collate();
        }

        // Max DB index length. See wp_get_db_schema().
        $max_index_length = 191;

        $tables = "
		CREATE TABLE {$wpdb->prefix}mlm_api_call_history (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			api_type varchar(200) NOT NULL,
			api_data TEXT NOT NULL,
			created_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY api_type (api_type)
		) $collate;
		";
        return $tables;
    }

}