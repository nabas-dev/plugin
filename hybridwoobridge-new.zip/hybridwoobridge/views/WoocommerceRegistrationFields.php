<?php
$domain = 'hybridwoobridge';
$checkout = WC()->checkout;
?>
<div id="my_custom_checkout_field" class="create-account">

<h3> <?php _e('Choose a sponsor',$domain) ?> </h3>
<?php
woocommerce_form_field( 'sponsor', array(
    'type'          => 'text',
    'label'         => __('Sponsor name', $domain ),
    'placeholder'   => __('Please fill Sponsor name', $domain ),
    'class'         => array('form-row-wide'),
    'required'      => true, // or false
), $checkout->get_value( 'sponsor' ) );
?>
</div>