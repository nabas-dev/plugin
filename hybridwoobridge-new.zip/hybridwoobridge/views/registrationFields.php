  <p>
      <label for="user_password"><?php _e( 'Password','hybridwoobridge' ); ?></label>
      <input type="password" name="user_password" id="user_password" class="input" value="" size="25" />
  </p>
  <p>
    <label for="user_confirm_password"><?php _e( 'Confirm password','hybridwoobridge' ); ?></label>
    <input type="password" name="user_confirm_password" id="user_confirm_password" class="input" value="" size="25" />
  </p>
<div class="hybridCustomRegistrationFields">
    <div class="row">
        <div class="col-md-7">
            <label><?php _e( 'Register as Affiliate ?','hybridwoobridge' ); ?></label>
        </div>
        <div class="col-md-5">
            <div class="checkboxHolder">
                <input type="checkbox" name="is_affiliate">
            </div>
        </div>
    </div>

    <div class="container sponsorField" style="display: none">
        <div class="panel">
            <div class="panel-body wizard-content">
                <div id="backoffice-form"  class="tab-wizard wizard-circle wizard clearfix">
                    <h6>Sponsor</h6>
                    <section>
                        <br/>
                        <div class="row">
                            <div class="col-sm-12 col-sm-push-12">
                                <div class="row form-row-custom inputcontainer">
                                    <label><?php _e( 'Sponsor name','hybridwoobridge' ); ?></label>
                                    <input required type="text" id="sponsor" name="sponsor" placeholder="sponsor" value="<?php echo isset($_POST['sponsor'])?$_POST['sponsor']:NULL; ?>" size="25" class="required">
                                    <div class="icon-container" style="display: none">
                                        <i class="loader"></i>
                                    </div>
                                </div>

                                        <h6 class="sponsor-name">Fname Lname</h6>

                            </div>
                        </div>
                    </section>

                    <h6>Profile</h6>
                    <section>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="row form-row-custom">
                                    <label><?php _e( 'First name','hybridwoobridge' ); ?></label>
                                    <input type="text" name="first_name"  value="<?php echo isset($_POST['first_name'])?$_POST['first_name']:NULL; ?>" size="25">
                                </div>
                                <div class="row form-row-custom">
                                    <label><?php _e( 'Last name','hybridwoobridge' ); ?></label>
                                    <input type="text" name="last_name"  value="<?php echo isset($_POST['last_name'])?$_POST['last_name']:NULL; ?>" size="25">
                                </div>
                                <div class="row form-row-custom">
                                    <label><?php _e( 'Phone number','hybridwoobridge' ); ?></label>
                                    <div class="input-group input-group-sm">
                                        <input  name="phone" id="phone" type="tel" class="form-control form-control-sm rounded-0 w-100" value="<?php echo isset($_POST['phone'])?$_POST['phone']:NULL; ?>">
                                        <div class="input-group-append">
                                            <span class="input-group-text rounded-0 fa fa-phone"></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="row form-row-custom">
                                    <label><?php _e( 'Date of birth','hybridwoobridge' ); ?></label>
                                    <input type="date" name="dob" id="dob" class="form-control" value="<?php echo isset($_POST['dob'])?$_POST['dob']:NULL; ?>">
                                </div>
                                <div class="form-group row form-row-custom">
                                    <label><?php _e( 'Gender','hybridwoobridge' ); ?></label>
                                    <div class="radio-list">
                                        <label>
                                            <input type="radio" checked="" name="gender" value="M" data-title="Male"> Male
                                        </label>
                                        <label>
                                            <input type="radio" name="gender" value="F" data-title="Female"> Female
                                        </label>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </section>

                    <h6>Address</h6>
                    <section>
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="row form-row-custom">
                                    <label><?php _e( 'Country','hybridwoobridge' ); ?></label>
                                    <select name="country" id="country" class="form-control browser-default custom-select">
                                        <option value="">Select a Country</option>
                                        <?php $countires = $this->getCountries();
                                        foreach ($countires as $country){

                                            $country_code=$country['id'];
                                            $country_name=$country['name'];

                                            echo "<option value='$country_code'>$country_name</option>";
                                        }
                                        ?>

                                    </select>

                                </div>
                                <div class="row form-row-custom">
                                    <label><?php _e( 'State','hybridwoobridge' ); ?></label>
                                    <select name="state" id="state" class="form-control browser-default custom-select">
                                        <option value="">Select a state</option>
                                        <?php $states = $this->getStates();
                                        foreach ($states as $state){

                                            $state_code=$state['id'];
                                            $state_name=$state['name'];

                                            echo "<option value='$state_code'>$state_name</option>";
                                        }
                                        ?>
                                    </select>
                                </div>
                                <div class="row form-row-custom">
                                    <label><?php _e( 'City','hybridwoobridge' ); ?></label>
                                    <input type="text" name="city"  value="<?php echo isset($_POST['city'])?$_POST['city']:NULL; ?>" size="25">
                                </div>
                                <div class="row form-row-custom">
                                    <label><?php _e( 'Pin code','hybridwoobridgebridge' ); ?></label>
                                    <input type="text" name="pin_code"  value="<?php echo isset($_POST['pin_code'])?$_POST['pin_code']:NULL; ?>" size="25">
                                </div>
                            </div>
                        </div>

                    </section>



                </div>
            </div>
        </div>
    </div>


</div>
