<?php echo $this->addCss('pluginConfig'); ?>
<?php echo $this->addCss('//maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css', true); ?>
<?php echo $this->addCss('//cdnjs.cloudflare.com/ajax/libs/Ladda/1.0.6/ladda.min.css', true); ?>
<?php echo $this->addJs('//cdnjs.cloudflare.com/ajax/libs/Ladda/1.0.6/spin.min.js', true); ?>
<?php echo $this->addJs('//cdnjs.cloudflare.com/ajax/libs/Ladda/1.0.6/ladda.min.js', true); ?>
<div class="hybridWooPluginSettings">
    <h2>Settings</h2>
    <form class="settingsForm">
        <?php
        settings_fields('hybridWooSettings-group');
        do_settings_sections('hybridWooSettings-group');
        ?>
        <div class="eachField">
            <label>Api endpoint</label>
            <div class="inputHolder flex">
                <input placeholder="API endpoint" type="text" name="hybridwoo_api_endpoint"
                       value="<?php echo esc_attr(get_option('hybridwoo_api_endpoint')); ?>">
            </div>
        </div>
        <div class="eachField">
            <label>API Token</label>
            <div class="inputHolder flex">
                <input placeholder="API token" type="text" name="hybridwoo_api_token"
                       value="<?php echo esc_attr(get_option('hybridwoo_api_token')); ?>">
            </div>
        </div>
        <div class="actions">
            <button class="saveSettings btn btn-success ladda-button" data-style="contract" type="button">
                save
            </button>
        </div>
    </form>
    <div class="successMessage">
        <i class="las la-check"></i> Information saved
    </div>
</div>
<script type="text/javascript">
    jQuery(function ($) {
        Ladda.bind('.ladda-button');

        $('.saveSettings').click(function () {
            $.post('<?php echo admin_url('options.php'); ?>', $('.hybridWooPluginSettings form').serialize(), function (response) {
                $('.successMessage').slideDown();

                setTimeout(() => {
                    $('.successMessage').slideUp();
                }, 2000);
                Ladda.stopAll();
            }).fail(response => {
                Ladda.stopAll();
            });
        });
    });
</script>