<?php
/*
Plugin Name: HybridMLM-WC Bridge
Plugin URI: https://www.hybridmlm.io/
Description: Plugin to connect woo-commerce with hybrid MLM
Author: HybridMLM
Author URI: https://www.hybridmlm.io/
License: GPLv2 or later
Text Domain: HybridMLM-WC
Version : 1.0.0
*/

// Make sure we don't expose any info if called directly

use HybridMLMWP\Inc\hooks;
use HybridMLMWP\Inc\install;
use HybridMLMWP\Inc\MlmApiController;

if (!function_exists('add_action')) {
    echo 'voilaa, nothing here';
    exit;
}

define_constants();
includes();
init_hooks();


/**
 *
 */
function define_constants()
{
    define('HYBRIDWOOBRIDGE_VERSION', '1.0.0');
    define('HYBRIDWOOBRIDGE_PLUGIN_NAME', 'HybridMLM-WC Bridge');
    define('HYBRIDWOOBRIDGE_PLUGIN_DIR', plugin_dir_path(__FILE__));
    define('HYBRIDWOOBRIDGE_PLUGIN_URL', site_url() . '/wp-content/plugins/HybridMLM-WC');
    define('HYBRIDWOOBRIDGE_VIEW_DIR', HYBRIDWOOBRIDGE_PLUGIN_DIR . 'views/');
    define('HYBRIDWOOBRIDGE_ASSETS_URL', HYBRIDWOOBRIDGE_PLUGIN_URL . '/assets/');
    define('HYBRIDMLM_API_ENDPOINT', 'http://localhost');
    define('HYBRIDMLM_DOMAIN', 'http://localhost');
}

/**
 *
 */
function includes()
{
    require_once HYBRIDWOOBRIDGE_PLUGIN_DIR . 'inc/install.php';
    require_once HYBRIDWOOBRIDGE_PLUGIN_DIR . 'vendor/autoload.php';
    require_once HYBRIDWOOBRIDGE_PLUGIN_DIR . 'inc/hooks.php';

    $hybridWooBridgeHook = new hooks();
    if (get_option('hybridwoo_wp_mlm_reg_option') == "mlm_to_wc") {
        require_once HYBRIDWOOBRIDGE_PLUGIN_DIR . 'inc/mlmapicontroller.php';
        $hybridWooBridgeMlmApi = new MlmApiController();
    }
}

/**
 *
 */
function init_hooks()
{
    register_activation_hook(__FILE__, 'activate_hybridwoobridge_plugin');
}


/**
 *
 */
function activate_hybridwoobridge_plugin()
{
    $hybridWooBridgeInstall = new install();
}
