<?php

namespace HybridMLMWP\Inc;

/**
 * Class hooks
 */
class MlmApiController
{
    /**
     * @return $this
     */
    function __construct()
    {
        $this->register_api_enpoint_urls();
        return $this;
    }

    /**
     * @param $token
     * @return bool
     */
    function validateToken($token)
    {
        $flag = $token == get_option('hybridwoo_api_token') ? true : false;
        if(!$flag){
            $response['code']=400;
            $response['error'][]="in valid api token !";
            exit(json_encode($response));
        }

        return $this;
    }

    /**
     * @return $this
     */
    function register_api_enpoint_urls()
    {
        add_action('rest_api_init', function () {
            register_rest_route('hybridwoobridge', 'mlm-register', array(
                'methods' => 'POST',
                'callback' => [$this, 'hybridWooBridgeRegistration'],
                'permission_callback' => '__return_true'
            ));
            register_rest_route('hybridwoobridge', 'verifyUsername', array(
                'methods' => 'POST',
                'callback' => [$this, 'hybridWooBridgeVerifyUsername'],
                'permission_callback' => '__return_true'
            ));
            register_rest_route('hybridwoobridge', 'verifyEmail', array(
                'methods' => 'POST',
                'callback' => [$this, 'hybridWooBridgeVerifyEmail'],
                'permission_callback' => '__return_true'
            ));
            register_rest_route('hybridwoobridge', 'addMLMProductToWP', array(
                'methods' => 'POST',
                'callback' => [$this, 'add_mlm_product_to_WP'],
                'permission_callback' => '__return_true'
            ));
            register_rest_route('hybridwoobridge', 'updateMLMProductToWP', array(
                'methods' => 'POST',
                'callback' => [$this, 'update_mlm_product_to_WP'],
                'permission_callback' => '__return_true'
            ));
        });

        return $this;
    }


    /**
     * @param $request
     */
    function hybridWooBridgeVerifyUsername($request){
        $response = false;
        $parameters = $request->get_params();

        $this->validateToken($parameters['api_key']);
        $username = sanitize_text_field($parameters['username']);

        if (!empty($username)) exit(json_encode(!username_exists($username)));

        exit(json_encode($response));
    }

    /**
     * @param $request
     */
    function hybridWooBridgeVerifyEmail($request){
        $response = false;
        $parameters = $request->get_params();

        $this->validateToken($parameters['api_key']);
        $email = sanitize_text_field($parameters['email']);

        if (!empty($email)) exit(json_encode(!email_exists($email)));

        exit(json_encode($response));
    }

    /**
     * @param $request
     */
    function hybridWooBridgeRegistration($request){
        $response = array();
        $parameters = $request->get_params();

        $this->validateToken($parameters['api_key']);
        $username = sanitize_text_field($parameters['username']);
        $email = sanitize_text_field($parameters['email']);
        $password = sanitize_text_field($parameters['password']);
        $role = isset($parameters['role'])?sanitize_text_field($parameters['role']):false;

        if (empty($username)) {
            $response['code']=406;
            $response['error'][] = __("Username field 'username' is required.");
            exit(json_encode($response));
        }
        if (empty($email)) {
            $response['code']=406;
            $response['error'][] =  __("Email field 'email' is required.");
            exit(json_encode($response));
        }
        if (empty($password)) {
            $response['code']=406;
            $response['error'][]= __("Password field 'password' is required.");
            exit(json_encode($response));
        }
        if (empty($role)) {
                $role = 'customer';
        } else {
            if ($GLOBALS['wp_roles']->is_role($role)) {
                if ($role == 'administrator' || $role == 'editor' || $role == 'author') {
                    $response['code']=406;
                    $response['error'][]= __("Role field 'role' is not a permitted. Only 'contributor', 'subscriber' and your custom roles are allowed.");
                    exit(json_encode($response));
                } else {
                    // Silence is gold
                }
            } else {
                $response['code']=406;
                $response['error'][]= __("Role field 'role' is not a valid. Check your User Roles from Dashboard.");
                exit(json_encode($response));
            }
        }

        $user_id = username_exists($username);
        if (!$user_id && email_exists($email) == false) {
            $user_id = wc_create_new_customer( $email, $username, $password );
            if (!is_wp_error($user_id)) {
                // Ger User Meta Data (Sensitive, Password included. DO NOT pass to front end.)
                $user = get_user_by('id', $user_id);


                //update user meta
                $this->updateUserMetaDataDetails($user_id,$parameters);
                // Ger User Data (Non-Sensitive, Pass to front end.)
                $response['code'] = 200;
                $response['wp_user_id'] =$user_id;
                $response['message'] = "User '" . $username . "' Registration was Successful";
            } else {
                $response['code'] = 300;
                $response['wp_user_id'] = $user_id;
                $response['message'] = "User '" . $username . "' Registration was Successful with warning";
            }
        } else {
            $response['code']=406;
            $response['error'][] = "Email already exists, please try 'Reset Password'";
            $response['data'][0] = $username;
            $response['data'][1] = $email;
            $response['data']['wp_user_id'] = $user_id;
        }

        exit(json_encode($response));
    }

    /**
     * @param $user_id
     * @param $parameters
     */
    function updateUserMetaDataDetails($user_id, $parameters){
        $isAffiliate = (isset($parameters['is_affiliate'])) ? true : false;
        $sponsor = (isset($parameters['sponsor'])) ? $parameters['sponsor'] : false;
        $mlmuserid = (isset($parameters['mlmuserid'])) ? $parameters['mlmuserid'] : false;
        $first_name = (isset($parameters['first_name'])) ? $parameters['first_name'] : false;
        $last_name = (isset($parameters['last_name'])) ? $parameters['last_name'] : false;
        $dob = (isset($parameters['dob'])) ? $parameters['dob'] : false;
        $country = (isset($parameters['country'])) ? $parameters['country'] : false;
        $state = (isset($parameters['state'])) ? $parameters['state'] : false;
        $city = (isset($parameters['city'])) ? $parameters['city'] : false;
        $gender = (isset($parameters['gender'])) ? $parameters['gender'] : false;
        $pin_code = (isset($parameters['pin_code'])) ? $parameters['pin_code'] : false;
        $phone = (isset($parameters['phone'])) ? $parameters['phone'] : false;

        update_user_meta($user_id, 'is_affiliate', sanitize_text_field($isAffiliate));
        update_user_meta($user_id, 'sponsor', sanitize_text_field($sponsor));
        update_user_meta($user_id, 'first_name', sanitize_text_field($first_name));
        update_user_meta($user_id, 'last_name', sanitize_text_field($last_name));
        update_user_meta($user_id, 'dob', sanitize_text_field($dob));
        update_user_meta($user_id, 'country', sanitize_text_field($country));
        update_user_meta($user_id, 'state', sanitize_text_field($state));
        update_user_meta($user_id, 'city', sanitize_text_field($city));
        update_user_meta($user_id, 'gender', sanitize_text_field($gender));
        update_user_meta($user_id, 'pin_code', sanitize_text_field($pin_code));
        update_user_meta($user_id, 'phone', sanitize_text_field($phone));
        update_user_meta($user_id, 'mlm_user_id', sanitize_text_field($mlmuserid));
    }

    /**
     * @param $request
     */
    function add_mlm_product_to_WP($request){
        $response = false;
        $parameters = $request->get_params();

        $this->validateToken($parameters['api_key']);
        $product_name = $parameters['product_name'];
        $image_url = $parameters['image_url'];
        $image_name = $parameters['image_name'];
        $product_description = $parameters['product_description'];
        $meta_data = $parameters['meta_data'];
        $product_id=$this->createProduct($product_name,$product_description,$image_url,$image_name,$meta_data);

        exit(json_encode($product_id));
    }

    /**
     * @param $product_name
     * @param $product_description
     * @param $image_url
     * @param $image_name
     * @param array $meta_data
     * @return mixed
     */
    function createProduct($product_name, $product_description, $image_url, $image_name, $meta_data=array()){

        $post_id = wp_insert_post( array(
            'post_title' => $product_name,
            'post_content' => $product_description,
            'post_status' => 'publish',
            'post_type' => "product",
        ) );
        $term_id = $this->getProductCategory('MLM packages');
        wp_set_object_terms( $post_id, $term_id, 'product_cat' );
        $this->updateProductMeta($post_id,$meta_data);
        $this->updateProductImage($post_id,$image_url,$image_name);

        return $post_id;
    }

    function getProductCategory($name){
        $category=get_term_by('name', $name, 'product_cat');
        if($category)
            return $category->term_id;

        return false;
    }


    /**
     * @param $post_id
     * @param array $meta_data
     * @return $this
     */
    function updateProductMeta($post_id, $meta_data=array()){
        update_post_meta( $post_id, '_visibility', $meta_data['visibility'] );
        update_post_meta( $post_id, '_stock_status', $meta_data['stock_status']);
        update_post_meta( $post_id, '_downloadable', 'no' );
        update_post_meta( $post_id, '_virtual', $meta_data['virtual'] );
        update_post_meta( $post_id, '_regular_price', $meta_data['price'] );
        update_post_meta( $post_id, '_sale_price', $meta_data['price'] );
        update_post_meta( $post_id, '_featured', 'no' );
        update_post_meta( $post_id, '_sku', $meta_data['slug'] );
        update_post_meta( $post_id, '_price', $meta_data['price'] );
        update_post_meta( $post_id, 'mlm_product_pv', $meta_data['pv'] );
        return $this;
    }

    function update_mlm_product_to_WP($request){

        $parameters = $request->get_params();

        $this->validateToken($parameters['api_key']);
        $product_id = $parameters['product_id'];
        $product_name = $parameters['product_name'];
        $product_description = $parameters['product_description'];
        $status = $parameters['status'];
        $meta_data = $parameters['meta_data'];
        $image_url = $parameters['image_url'];
        $image_name = $parameters['image_name'];
        $product_id=$this->updateProduct($product_id,$product_name,$product_description,$status,$meta_data);
        $this->updateProductImage($product_id,$image_url,$image_name);

        exit(json_encode($product_id));
    }

    function updateProduct($product_id,$product_name,$product_description,$status,$meta_data){
        $my_post = array(
            'ID'           => $product_id,
            'post_title'   => $product_name,
            'post_content' => $product_description,
            'post_status'  => $status,
        );

        $post_id = wp_update_post( $my_post );

        $this->updateProductMeta($post_id,$meta_data);
        return $post_id;
    }

    function updateProductImage($post_id,$image_url,$image_name){
        if(!($post_id && $image_url && $image_name))
            return;

        // only need these if performing outside of admin environment
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        // example image
        $image = $image_url;

        // magic sideload image returns an HTML image, not an ID
        $media = media_sideload_image($image, $post_id);


        // therefore we must find it so we can set it as featured ID
        if(!empty($media) && !is_wp_error($media)){
            $args = array(
                'post_type' => 'attachment',
                'posts_per_page' => -1,
                'post_status' => 'any',
                'post_parent' => $post_id
            );

            // reference new image to set as featured
            $attachments = get_posts($args);

            if(isset($attachments) && is_array($attachments)){
                foreach($attachments as $attachment){
                    // grab source of full size images (so no 300x150 nonsense in path)
                    $image = wp_get_attachment_image_src($attachment->ID, 'full');
                    // determine if in the $media image we created, the string of the URL exists
                    if(strpos($media, $image[0]) !== false){
                        // if so, we found our image. set it as thumbnail
                        set_post_thumbnail($post_id, $attachment->ID);
                        // only want one image
                        break;
                    }
                }
            }
        }
    }
}
