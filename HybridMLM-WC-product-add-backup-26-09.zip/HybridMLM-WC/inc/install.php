<?php

namespace HybridMLMWP\Inc;

/**
 * Class install
 * @package HybridWoo\Inc
 */
class install
{
    public function __construct() {
        $this->create_tables();
        $this->create_wp_pages();
        $this->createProductCategory('MLM packages','product_cat','mlm product category','mlm-packages');
        return $this;
    }

    /**
     * @param $category_name
     * @param $taxonomy
     * @param string $description
     * @param string $slug
     */
    function createProductCategory($category_name, $taxonomy, $description='', $slug=''){
        wp_insert_term(
            $category_name,
            $taxonomy,
            array(
            'description' => $description,
            'parent' => 0, // optional
            'slug' => $slug // optional
        ) );
    }

    /**
     * Install DB and create cron events when activated.
     *
     * @return void
     */
    public static function create_tables() {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        dbDelta( self::get_schema() );
    }

    /**
     *
     */
    public static function create_wp_pages(){
        $page_content='[hybridwoobridge_registration_form]';
        self::create_reg_form_page('MLM Registration','mlm-registration-form',$page_content);
    }

    /**
     * @param string $title
     * @param string $slug
     * @param string $page_content
     * @param string $post_type
     * @return false
     */

    function create_reg_form_page($title='Form', $slug='form', $page_content = '', $post_type = 'page'){
        $page_id=false;
        $page_args = array(
            'post_type' => $post_type,
            'post_title' => $title,
            'post_content' => $page_content,
            'post_status' => 'publish',
            'post_author' => 1,
            'post_slug' => $slug
        );

        if(post_exists($title) === 0){
            $page_id = wp_insert_post($page_args);
        }
    return $page_id;
    }
    /**
     * Get database schema.
     *
     * @return string
     */
    protected static function get_schema() {
        global $wpdb;

        if ( $wpdb->has_cap( 'collation' ) ) {
            $collate = $wpdb->get_charset_collate();
        }

        $tables = "
		CREATE TABLE {$wpdb->prefix}hybridmlm_api_history (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			api_type varchar(200) NOT NULL,
			api_data TEXT NOT NULL,
			created_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY api_type (api_type)
		) $collate;
		";

        return $tables;
    }
}