<?php

namespace HybridMLMWP\Inc;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use Psr\Http\Message\ResponseInterface;

/**
 * Class hooks
 */
class hooks
{
    /**
     * @return $this
     */
    function __construct()
    {
        $this->adminHooks()->registration()->ajax_requests()->wooCommerceHooks();

        return $this;
    }

    /**
     * @return $this
     */
    function wooCommerceHooks()
    {
        if(get_option('hybridwoo_wp_mlm_reg_option')=="wc_to_mlm") {

                add_action('woocommerce_created_customer', [$this, 'checkoutRegisterToMLM'], 10, 3);

                add_action('woocommerce_register_form_start', [$this, 'custom_checkout_fields_before_billing_details'], 20);
                // Custom checkout fields validation
                add_action('woocommerce_register_post', [$this, 'custom_checkout_field_validate'], 10, 3);
                // Save custom checkout fields the data to the order
                add_action('woocommerce_checkout_create_order', [$this, 'custom_checkout_field_update_meta'], 10, 2);

        }

        add_action('woocommerce_thankyou', [$this, 'sendOrderData'], 10, 1);

        add_filter( 'woocommerce_get_price_html', [$this,'mlm_alter_price_display'], 9999, 2 );

        add_action( 'woocommerce_before_calculate_totals', [$this,'mlm_alter_price_cart'], 9999 );

        add_action( 'woocommerce_product_options_general_product_data', [$this,'hybrid_create_custom_product_field'] );
        add_action( 'woocommerce_process_product_meta', [$this,'hybrid_save_custom_product_field'] );
        //add_action( 'woocommerce_before_add_to_cart_button', [$this,'hybrid_display_custom_field'] );

        add_action( 'updated_post_meta', [$this,'hybrid_sync_on_product_save'], 10, 4 );


            add_filter( 'get_terms', [$this,'hybrid_hide_mlm_category_product'], 10, 3 );
            add_action( 'woocommerce_product_query', [$this,'hybrid_hide_products_category_shop'] );



        return $this;
    }


    /**
     *
     */
    function hybrid_create_custom_product_field() {
        $args = array(
            'id' => 'mlm_product_pv',
            'label' => __( 'MLM Product PV', 'HybridMLM-WC' ),
            'class' => 'hybrid-custom-field',
            'desc_tip' => true,
            'description' => __( 'Enter MLM Product Pv.', 'HybridMLM-WC' ),
        );
        woocommerce_wp_text_input( $args );
    }


    /**
     * @param $post_id
     */
    function hybrid_save_custom_product_field($post_id ) {
        $product = wc_get_product( $post_id );
        $title = isset( $_POST['mlm_product_pv'] ) ? $_POST['mlm_product_pv'] : '';
        $product->update_meta_data( 'mlm_product_pv', sanitize_text_field( $title ) );
        $product->save();
    }

    function hybrid_display_custom_field() {
        global $post;
        // Check for the custom field value
        $product = wc_get_product( $post->ID );
        $title = $product->get_meta( 'mlm_product_pv' );
        if( $title ) {
            // Only display our field if we've got a value for the field title
            printf(
                esc_html( $title )
            );
        }
    }




    /**
     * @param $customer_id
     * @param $new_customer_data
     * @param $password_generated
     * @return $this
     * @throws GuzzleException
     */
    function checkoutRegisterToMLM($customer_id, $new_customer_data, $password_generated ) {

        $sponsor = (isset($_POST['sponsor'])) ? $_POST['sponsor'] : false;
        $password=(isset($_POST['account_password'])) ?sanitize_text_field($_POST['account_password']):(isset($_POST['password'])) ?sanitize_text_field($_POST['password']):$password_generated;

        update_user_meta($customer_id, 'sponsor', sanitize_text_field($sponsor));

        $response=$this->WCSendRegistrationData($customer_id,$password);
        $member_id = json_decode($response, true)[0]['user']['member_id'];
        $mlm_id = json_decode($response, true)[0]['user']['id'];
        update_user_meta($customer_id, 'mlm_member_id', sanitize_text_field($member_id));
        update_user_meta($customer_id, 'mlm_user_id', sanitize_text_field($mlm_id));
        $this->keepHistory('hybridmlm_api_history',"woocomme_register_call_$customer_id",$response);
        return $this;
    }

    /**
     * @param $userId
     * @param $password
     * @return string
     * @throws GuzzleException
     */
    function WCSendRegistrationData($userId, $password)
    {

        $client = $this->getAPIClient();
        $user = get_user_by('id', $userId);
        return $client->request('post', '', [
            'form_params' => [
                'token' => get_option('hybridwoo_api_token'),
                'action' => 'register',
                'data' => [
                    'username' => $user->user_login,
                    'email' => $user->user_email,
                    'sponsor' => get_user_meta($userId, 'sponsor', true),
                    'firstname' => get_user_meta($userId, 'billing_first_name', true),
                    'lastname' => get_user_meta($userId, 'billing_last_name', true),
                    'dob' => get_user_meta($userId, 'dob', true),
                    'country_id' => get_user_meta($userId, 'billing_country', true),
                    'state_id' => get_user_meta($userId, 'billing_state', true),
                    'city_id' => get_user_meta($userId, 'billing_city', true),
                    'gender' => get_user_meta($userId, 'gender', true),
                    'pin_code' => get_user_meta($userId, 'billing_postcode', true),
                    'phone' => get_user_meta($userId, 'phone', true),
                    'password' => $password,
                    'wp_user_id' => $userId
                ]
            ]
        ])->getBody()->getContents();
    }
    /**
     * @return mixed
     */
    function custom_checkout_fields_before_billing_details(){
        return $this->view('WoocommerceRegistrationFields');
    }

    /**
     * @param $username
     * @param $email
     * @param $validation_errors
     * @throws GuzzleException
     */
    function custom_checkout_field_validate($username, $email, $validation_errors) {
        if ( isset($_POST['sponsor'])){
            if (!$this->verifySponsor($_POST['sponsor']))
                $validation_errors->add( 'sponsor', __( '<strong>Error</strong>: Invalid Sponsor!', 'woocommerce' ) );
            if ($this->verifyUsername($username))
                $validation_errors->add('username', 'The username seems to be exist !!');
            if ($this->verifyEmail($email))
                $validation_errors->add('email', 'The email seems to be taken or not valid !');

        }

    }


    /**
     * @param $order
     * @param $data
     */
    function custom_checkout_field_update_meta($order, $data ){

    }
    /**
     * @param $order_id
     * @return bool|ResponseInterface
     * @throws GuzzleException
     */
    function sendOrderData($order_id)
    {
        if (!$order_id)
            return false;

        $client = $this->getAPIClient();
        $order = wc_get_order($order_id);
        $items = $order->get_items();
        foreach ( $items as $k=>$item ) {
            $products[$k]['name']=$item->get_name();
            $products[$k]['product_id'] = $item->get_product_id();
            $products[$k]['variation_id'] = $item->get_variation_id();
            $products[$k]['quantity'] = $item->get_quantity();
            $products[$k]['subtotal'] = $item->get_subtotal();
            $products[$k]['total'] = $item->get_total();
            $products[$k]['tax'] = $item->get_subtotal_tax();
            $products[$k]['taxclass'] = $item->get_tax_class();
            $products[$k]['taxstat'] = $item->get_tax_status();
            $products[$k]['allmeta'] = $item->get_meta_data();
            $products[$k]['type'] = $item->get_type();
            $product = $item->get_product();
            $products[$k]['pv'] = $product->get_meta('mlm_product_pv', true);
        }

        return $client->request('post', '', [
            'form_params' => [
                'token' => get_option('hybridwoo_api_token'),
                'action' => 'purchase',
                'data' => [
                    'orderId' => $order->get_id(),
                    'wp_customer_id' => $order->get_user_id(),
                    'currency' => $order->get_currency(),
                    'sub_total' => $order->get_subtotal(),
                    'total' => $order->get_total(),
                    'items' => $products
                ],
            ]
        ]);
    }
//discount

    /**
     * @param $wp_user_id
     * @return boolean
     */
    function check_mlm_user($wp_user_id){
    if(!$wp_user_id) return false;
        $mlm_user_id=get_user_meta( $wp_user_id, 'mlm_user_id',  true );
        if($mlm_user_id) return $mlm_user_id;

        return false;
    }


    /**
     * @param $price_html
     * @param $product
     * @return mixed
     */
    function mlm_alter_price_display($price_html, $product ) {

        $discount_percentage=get_option('hybridwoo_discount_price');
        if($discount_percentage==0) return $price_html;

        // ONLY ON FRONTEND
        if ( is_admin() ) return $price_html;

        // ONLY IF PRICE NOT NULL
        if ( '' === $product->get_price() ) return $price_html;

        // IF CUSTOMER LOGGED IN, APPLY 20% DISCOUNT
        if ( wc_current_user_has_role( 'customer' ) && $this->check_mlm_user(get_current_user_id())) {
            $orig_price = wc_get_price_to_display( $product );
            $price_html = wc_price( $orig_price - ($orig_price * $discount_percentage / 100) );
        }

        return $price_html;

    }


    /**
     * @param $cart
     */
    function mlm_alter_price_cart($cart ) {

        $discount_percentage=get_option('hybridwoo_discount_price');
        if($discount_percentage==0) return;

        if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;

        if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 ) return;

        // IF CUSTOMER NOT LOGGED IN, DONT APPLY DISCOUNT
        if ( ! wc_current_user_has_role( 'customer' ) ) return;

        if ( ! $this->check_mlm_user(get_current_user_id()) ) return;



        // LOOP THROUGH CART ITEMS & APPLY 20% DISCOUNT
        foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) {
            $product = $cart_item['data'];
            $price = $product->get_price();
            $cart_item['data']->set_price( $price - ($price * $discount_percentage/100) );
        }

    }

    /**
     * @return $this
     */
    function ajax_requests()
    {
        add_action('wp_ajax_get_states_by_country', [$this, 'get_states_by_country']);
        add_action('wp_ajax_nopriv_get_states_by_country', [$this, 'get_states_by_country']);
        add_action('wp_ajax_verify_user_login', [$this, 'verifyUserName_ajax']);
        add_action('wp_ajax_nopriv_verify_user_login', [$this, 'verifyUserName_ajax']);
        add_action('wp_ajax_verify_user_email', [$this, 'verifyUserEmail_ajax']);
        add_action('wp_ajax_nopriv_verify_user_email', [$this, 'verifyUserEmail_ajax']);
        add_action('wp_ajax_verify_sponsor', [$this, 'verifySponsor_ajax']);
        add_action('wp_ajax_nopriv_verify_sponsor', [$this, 'verifySponsor_ajax']);

        return $this;
    }

    /**
     * @return $this
     */
    function registration()
    {

        if (get_option('hybridwoo_wp_mlm_reg_option') == "wc_to_mlm") {
            $isAffiliate = (isset($_POST['is_affiliate'])) ? true : false;
            add_action('register_form', [$this, 'customRegistrationFields']);
            add_filter('random_password', [$this, 'addUserPassword'], 10, 4);
            if ($isAffiliate) {
                add_action('user_register', [$this, 'processCustomRegistrationFields']);
                add_filter('registration_errors', [$this, 'validateRegistrationFields'], 10, 3);
            }
            add_shortcode('hybridwoobridge_registration_form', [$this, 'generate_registration_form']);
        }

        return $this;
    }

    /**
     * @return $this
     */
    function adminHooks()
    {
        if (is_admin()) {
            add_action('admin_menu', [$this, 'pluginConfig']);
            add_action('admin_init', [$this, 'registerSettings']);
        }

        return $this;
    }

    /**
     * @return ResponseInterface
     */
    function get_states_by_country()
    {
        $country_id = (isset($_POST['country_id'])) ? $_POST['country_id'] : false;
        $states = $this->getStates($country_id);

        exit(json_encode($states));
    }

    /**
     * @param $default
     * @return ResponseInterface
     * @throws GuzzleException
     */
    function getStates($default = 1)
    {
        $client = $this->getAPIClient();

        $result = $client->request('post', '', [
            'form_params' => [
                'token' => get_option('hybridwoo_api_token'),
                'action' => 'getStates',
                'data' => [
                    'default' => $default
                ],
            ]
        ])->getBody()->getContents();

        return json_decode($result, true);
    }

    /**
     * @return Client
     */
    function getAPIClient()
    {
        return new Client([
            'base_uri' => get_option('hybridwoo_api_endpoint'),
            // You can set any number of default request options.
            'timeout' => 2.0,
        ]);
    }

    /**
     * @param $atts
     * @return mixed
     */
    function generate_registration_form($atts)
    {
        if(is_admin()) return;
        $atts = shortcode_atts(array(), $atts, 'hybridwoobridge_registration_form');
        $this->registerStyleScript();
        wp_enqueue_style('bootstrap-css');
        wp_enqueue_style('telinput-css');
        wp_enqueue_script('slim-js');
        wp_enqueue_script('propper-js');
        wp_enqueue_script('jquery321-js');
        wp_enqueue_script('bootstrap-js');
        wp_enqueue_script('jquery-validate1192-js');
        wp_enqueue_script('intl-tel-input');
        wp_enqueue_script('jquery-steps110');
        wp_enqueue_style('woohybrid_registration_custom_fields');
        wp_enqueue_style('woohybrid_registration_form_wizard');
        wp_enqueue_script('hybrid-registration-script-js');

        return $this->shortCodeRegistrationFields();
        exit();
    }

    function registerStyleScript()
    {
        wp_register_style('bootstrap-css', '//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css');
        wp_register_style('telinput-css', '//cdnjs.cloudflare.com/ajax/libs/intl-tel-input/12.1.6/css/intlTelInput.css');
        wp_register_script('slim-js', '//code.jquery.com/jquery-3.3.1.slim.min.js', ['jquery'], null, true);
        wp_register_script('propper-js', '//cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js', ['jquery'], null, true);
        wp_register_script('jquery321-js', '//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js', ['jquery'], null, true);
        wp_register_script('bootstrap-js', '//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js', ['jquery'], null, true);
        wp_register_script('jquery-validate1192-js', '//cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.js', ['jquery'], null, false);
        wp_register_script('intl-tel-input', '//cdnjs.cloudflare.com/ajax/libs/intl-tel-input/12.1.6/js/intlTelInput.min.js', ['jquery'], null, false);
        wp_register_script('jquery-steps110', '//cdnjs.cloudflare.com/ajax/libs/jquery-steps/1.1.0/jquery.steps.min.js', ['jquery'], null, false);
        wp_register_style('woohybrid_registration_custom_fields', $this->stylePath('registration'), ['bootstrap-css']);
        wp_register_style('woohybrid_registration_form_wizard', $this->stylePath('form-wizard'), ['bootstrap-css']);
        wp_register_script('hybrid-registration-script-js', $this->jsPath('registration'), ['jquery'], null, false);
        wp_localize_script('hybrid-registration-script-js', 'my_ajax_object', array('ajax_url' => admin_url('admin-ajax.php')));
    }

    /**
     * @param null $file
     * @return string
     */
    function stylePath($file = null)
    {
        return HYBRIDWOOBRIDGE_ASSETS_URL . 'css/' . $file . '.css';
    }

    /**
     * @param null $file
     * @return string
     */
    function jsPath($file = null)
    {
        return HYBRIDWOOBRIDGE_ASSETS_URL . 'js/' . $file . '.js';
    }

    /**
     * @return mixed
     */
    function shortCodeRegistrationFields()
    {
        ob_start();
        $this->view('shortCodeRegistrationFields');
        $shorcode_php_function = ob_get_clean();

        return $shorcode_php_function;
    }

    /**
     * @param $path
     * @param string $extension
     * @return mixed
     */
    function view($path, $extension = '.php')
    {
        $view = include HYBRIDWOOBRIDGE_VIEW_DIR . $path . $extension;

        return $view;
    }

    /**
     * @return $this
     */
    function enqueueStyles()
    {

            wp_enqueue_style('bootstrap-css');
            wp_enqueue_style('telinput-css');
            wp_enqueue_script('slim-js');
            wp_enqueue_script('propper-js');
            wp_enqueue_script('jquery321-js');
            wp_enqueue_script('bootstrap-js');
            wp_enqueue_script('jquery-validate1192-js');
            wp_enqueue_script('intl-tel-input');
            wp_enqueue_script('jquery-steps110');
            wp_enqueue_style('woohybrid_registration_custom_fields');
            wp_enqueue_style('woohybrid_registration_form_wizard');
            wp_enqueue_script('hybrid-registration-script-js');


        return $this;
    }

    /**
     * @return $this
     */
    function registerSettings()
    {
        register_setting('hybridWooSettings-group', 'hybridwoo_api_endpoint');
        register_setting('hybridWooSettings-group', 'hybridwoo_api_token');
        register_setting('hybridWooSettings-group', 'hybridwoo_wp_mlm_reg_option');
        register_setting('hybridWooSettings-group', 'hybridwoo_discount_price');
        register_setting('hybridWooSettings-group', 'mlm_checkoutpage_registration');

        return $this;
    }

    /**
     * @return mixed
     */
    function customRegistrationFields()
    {
        return $this->view('registrationFields');
    }

    /**
     * @param $user_id
     * @throws GuzzleException
     */
    function processCustomRegistrationFields($user_id)
    {
        $isAffiliate = (isset($_POST['is_affiliate'])) ? true : false;
        $sponsor = (isset($_POST['sponsor'])) ? $_POST['sponsor'] : false;
        $first_name = (isset($_POST['first_name'])) ? $_POST['first_name'] : false;
        $last_name = (isset($_POST['last_name'])) ? $_POST['last_name'] : false;
        $dob = (isset($_POST['dob'])) ? $_POST['dob'] : false;
        $country = (isset($_POST['country'])) ? $_POST['country'] : false;
        $state = (isset($_POST['state'])) ? $_POST['state'] : false;
        $city = (isset($_POST['city'])) ? $_POST['city'] : false;
        $gender = (isset($_POST['gender'])) ? $_POST['gender'] : false;
        $pin_code = (isset($_POST['pin_code'])) ? $_POST['pin_code'] : false;
        $phone = (isset($_POST['phone'])) ? $_POST['phone'] : false;

        update_user_meta($user_id, 'is_affiliate', sanitize_text_field($isAffiliate));
        update_user_meta($user_id, 'sponsor', sanitize_text_field($sponsor));
        update_user_meta($user_id, 'first_name', sanitize_text_field($first_name));
        update_user_meta($user_id, 'last_name', sanitize_text_field($last_name));
        update_user_meta($user_id, 'dob', sanitize_text_field($dob));
        update_user_meta($user_id, 'country', sanitize_text_field($country));
        update_user_meta($user_id, 'state', sanitize_text_field($state));
        update_user_meta($user_id, 'city', sanitize_text_field($city));
        update_user_meta($user_id, 'gender', sanitize_text_field($gender));
        update_user_meta($user_id, 'pin_code', sanitize_text_field($pin_code));
        update_user_meta($user_id, 'phone', sanitize_text_field($phone));

        $this->keepHistory('hybridmlm_api_history', "user_register_$user_id", serialize($_POST));
        $response = $this->sendRegistrationData($user_id);
        $member_id = json_decode($response, true)[0]['user']['member_id'];
        $mlm_id = json_decode($response, true)[0]['user']['id'];
        update_user_meta($user_id, 'mlm_member_id', sanitize_text_field($member_id));
        update_user_meta($user_id, 'mlm_user_id', sanitize_text_field($mlm_id));
        $this->keepHistory('hybridmlm_api_history', "user_register_response_$user_id", $response);
    }

    /**
     * @param $table_name
     * @param $type
     * @param $data
     */
    function keepHistory($table_name, $type, $data)
    {
        global $wpdb;

        $wpdb->insert($wpdb->prefix . $table_name, array(
            'api_type' => $type,
            'api_data' => $data
        ));
    }

    /**
     * @param $userId
     * @return string
     * @throws GuzzleException
     */
    function sendRegistrationData($userId)
    {
        $client = $this->getAPIClient();
        $user = get_user_by('id', $userId);

        return $client->request('post', '', [
            'form_params' => [
                'token' => get_option('hybridwoo_api_token'),
                'action' => 'register',
                'data' => [
                    'username' => $user->user_login,
                    'email' => $user->user_email,
                    'sponsor' => get_user_meta($userId, 'sponsor', true),
                    'firstname' => get_user_meta($userId, 'first_name', true),
                    'lastname' => get_user_meta($userId, 'last_name', true),
                    'dob' => get_user_meta($userId, 'dob', true),
                    'country_id' => get_user_meta($userId, 'country', true),
                    'state_id' => get_user_meta($userId, 'state', true),
                    'city_id' => get_user_meta($userId, 'city', true),
                    'gender' => get_user_meta($userId, 'gender', true),
                    'pin_code' => get_user_meta($userId, 'pin_code', true),
                    'phone' => get_user_meta($userId, 'phone', true),
                    'password' => sanitize_text_field($_POST['user_password']),
                    'wp_user_id' => $userId
                ]
            ]
        ])->getBody()->getContents();
    }

    /**
     * @param $pass
     * @return string
     */
    function addUserPassword($pass)
    {
        if (isset($_POST['user_password']))
            return sanitize_text_field($_POST['user_password']);

        return $pass;
    }

    /**
     * @param $errors
     * @param $sanitized_user_login
     * @param $user_email
     * @return mixed
     */
    function validateRegistrationFields($errors, $sanitized_user_login, $user_email)
    {
        if ($this->verifyUsername($_POST['user_login']))
            $errors->add('username', 'The username seems to be exist !!');
        if ($this->verifyEmail($_POST['user_email']))
            $errors->add('email', 'The email seems to be taken or not valid !');
        if (!$this->verifySponsor($_POST['sponsor']))
            $errors->add('sponsor', 'This sponsor does not exist !');
        if (!$this->verifyUserPassword($_POST['user_password']))
            $errors->add('sponsor', 'Password required !');
        if (!$this->verifyUserDetails('first_name', 'text'))
            $errors->add('first_name', 'First name required !');
        if (!$this->verifyUserDetails('last_name', 'text'))
            $errors->add('first_name', 'Last name required !');
        if (!$this->verifyUserDetails('dob', 'date'))
            $errors->add('first_name', 'Date of birth required !');
        if (!$this->verifyUserDetails('country', 'select'))
            $errors->add('first_name', 'Select a country !');
        if (!$this->verifyUserDetails('state', 'select'))
            $errors->add('first_name', 'Select a state !');
        if (!$this->verifyUserDetails('city', 'select'))
            $errors->add('first_name', 'City is required !');
        if (!$this->verifyUserDetails('gender', 'select'))
            $errors->add('gender', 'Select gender !');
        if (!$this->verifyUserDetails('pin_code', 'text'))
            $errors->add('pin_code', 'Pin code is required !');
        if (!$this->verifyUserDetails('phone', 'text'))
            $errors->add('pin_code', 'phone is required !');

        return $errors;
    }

    /**
     * @param $username
     * @return ResponseInterface
     * @throws GuzzleException
     */
    function verifyUsername($username)
    {
        if (username_exists($username)) return json_decode("true");

        $client = $this->getAPIClient();
        $result = $client->request('post', '', [
            'form_params' => [
                'token' => get_option('hybridwoo_api_token'),
                'action' => 'verifyUsername',
                'data' => [
                    'username' => $username
                ],
            ]
        ])->getBody()->getContents();

        return json_decode($result, true)['status'];
    }

    /**
     * @param $email
     * @return ResponseInterface
     * @throws GuzzleException
     */
    function verifyEmail($email)
    {
        if (email_exists($email)) return json_decode("true");
        $client = $this->getAPIClient();
        $result = $client->request('post', '', [
            'form_params' => [
                'token' => get_option('hybridwoo_api_token'),
                'action' => 'verifyEmail',
                'data' => [
                    'email' => $email
                ],
            ]
        ])->getBody()->getContents();

        return json_decode($result, true)['status'];
    }

    /**
     * @param $sponsor
     * @throws GuzzleException
     */
    function verifySponsor($sponsor)
    {
        $client = $this->getAPIClient();
        $result = $client->request('post', '', [
            'form_params' => [
                'token' => get_option('hybridwoo_api_token'),
                'action' => 'verifySponsor',
                'data' => [
                    'sponsor' => $sponsor
                ],
            ]
        ])->getBody()->getContents();

        return json_decode($result, true)['status'];
    }

    /**
     * @param $password
     * @return  boolean
     */
    function verifyUserPassword($password)
    {
        return sanitize_text_field($password);
    }

    /**
     * @param $key
     * @param $input_type
     * @return  boolean
     */
    function verifyUserDetails($key, $input_type)
    {
        $flag = false;
        switch ($input_type) {
            case "date":
                $flag = true;
                break;
            case "text":
                $value = isset($_POST[$key]) ? $_POST[$key] : false;
                $flag = ($value == false) ? false : true;
                break;
            case "select":
                $value = isset($_POST[$key]) ? $_POST[$key] : false;
                $flag = ($value == false) ? false : true;
                break;
            default:
                $value = isset($_POST[$key]) ? $_POST[$key] : false;
                $flag = ($value == 0) ? false : true;

        }

        return $flag;

    }

    /**
     * @param $default
     * @return ResponseInterface
     * @throws GuzzleException
     */
    function getCountries($default = '')
    {
        $client = $this->getAPIClient();
        $result = $client->request('post', '', [
            'form_params' => [
                'token' => get_option('hybridwoo_api_token'),
                'action' => 'getCountries',
                'data' => [
                    'default' => $default
                ],
            ]
        ])->getBody()->getContents();

        return json_decode($result, true);
    }

    /**
     * @param $user_name
     * @param $met_key
     * @throws GuzzleException
     */
    function getUserMetaDataMLM($user_name, $met_key)
    {
        $client = $this->getAPIClient();
        $result = $client->request('post', '', [
            'form_params' => [
                'token' => get_option('hybridwoo_api_token'),
                'action' => 'getUserMetaData',
                'username' => $user_name,
                'met_key' => $met_key
            ]
        ])->getBody()->getContents();

        exit($result);
    }

    /**
     * @param user_login
     * @return string
     */
    function verifyUserName_ajax()
    {
        $user_name = isset($_POST['user_login']) ? sanitize_text_field($_POST['user_login']) : false;
        if ($user_name) {
            if ($this->verifyUsername($user_name)) {
                exit(json_encode(false));
            } else {
                exit(json_encode("ok"));
            }
        } else
            exit(json_encode(false));

        exit(json_encode(false));
    }

    /**
     * @param $_POST ['user_email']
     * @return boolean
     */
    function verifyUserEmail_ajax()
    {
        $user_email = isset($_POST['user_email']) ? sanitize_text_field($_POST['user_email']) : false;
        if ($user_email) {
            if ($this->verifyEmail($user_email)) {
                exit(json_encode(false));
            } else {
                exit(json_encode("ok"));
            }

        } else
            exit(json_encode(false));
    }

    /**
     * @throws GuzzleException
     */
    function verifySponsor_ajax()
    {
        $sponsor = isset($_POST['sponsor']) ? sanitize_text_field($_POST['sponsor']) : false;
        if ($sponsor) {
            if ($this->verifySponsor($sponsor))
                exit(json_encode("ok"));
            else
                exit(json_encode(false));
        } else
            exit(json_encode(false));
    }

    /**
     * @param $path
     * @param bool $absolute
     * @return string
     */
    function addCss($path, $absolute = false)
    {
        return '<link rel="stylesheet" type="text/css" href="' . ($absolute ? $path : $this->stylePath($path)) . '" />';
    }

    /**
     * @param $path
     * @param bool $absolute
     * @return string
     */
    function addJs($path, $absolute = false)
    {
        return '<script type="text/javascript" src="' . ($absolute ? $path : $this->jsPath($path)) . '"></script>';
    }

    /**
     * @return $this
     */
    function pluginConfig()
    {
        add_options_page(HYBRIDWOOBRIDGE_PLUGIN_NAME, HYBRIDWOOBRIDGE_PLUGIN_NAME, 'manage_options', 'hybridwoobridge', [$this, 'pluginConfigPage'], 26);

        return $this;
    }

    /**
     * @return mixed
     */
    function pluginConfigPage()
    {
        return $this->view('pluginConfig');
    }


    function hybrid_sync_on_product_save( $meta_id, $post_id, $meta_key, $meta_value ) {

        if ( $meta_key == '_edit_lock' ) { // we've been editing the post
            if ( get_post_type( $post_id ) == 'product' ) { // we've been editing a product
                $product = wc_get_product( $post_id );
                // do something with this product
                $terms = get_the_terms( $post_id, 'product_cat' );
                foreach ($terms as $term) {

                    $product_cat_slug = $term->slug;
                    if($product_cat_slug=="mlm-packages"){
                        if(is_admin()) die("you can't edit $product_cat_slug Product");
                    }


                    break;
                }
            }
        }
    }


    function hybrid_hide_mlm_category_product( $terms, $taxonomies, $args ) {

        if(!is_user_logged_in()) $terms;

        $new_terms 	= array();
        $hide_category 	= array( 17 ); // Ids of the category you don't want to display on the shop page

        // if a product category and on the shop page
        if ( in_array( 'product_cat', $taxonomies ) && !is_admin() && is_shop() ) {


            foreach ( $terms as $key => $term ) {

                if ( ! in_array( $term->term_id, $hide_category ) ) {
                    $new_terms[] = $term;
                }
            }

            $terms = $new_terms;
        }
        return $terms;
    }



    function hybrid_hide_products_category_shop( $q ) {

        if(!is_user_logged_in()) return;

        $tax_query = (array) $q->get( 'tax_query' );

        $tax_query[] = array(
            'taxonomy' => 'product_cat',
            'field' => 'slug',
            'terms' => array( 'mlm-packages' ), // Category slug here
            'operator' => 'NOT IN'
        );


        $q->set( 'tax_query', $tax_query );

    }

}