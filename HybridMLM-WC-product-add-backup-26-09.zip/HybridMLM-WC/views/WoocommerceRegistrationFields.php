<?php
$domain = 'hybridwoobridge';
$checkout = WC()->checkout;
?>
<div id="my_custom_checkout_field" class="create-account">
    <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
        <label for="sponsor"><?php esc_html_e( 'Sponsor', 'woocommerce' ); ?>&nbsp;<span class="required">*</span></label>
        <input type="text" class="woocommerce-Input woocommerce-Input--text input-text" name="sponsor" id="sponsor" autocomplete="sponsor" value="<?php echo ( ! empty( $_POST['sponsor'] ) ) ? esc_attr( wp_unslash( $_POST['sponsor'] ) ) : ''; ?>" />
    </p>
</div>