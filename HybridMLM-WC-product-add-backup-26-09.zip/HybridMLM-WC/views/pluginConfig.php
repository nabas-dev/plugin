<?php echo $this->addCss('pluginConfig'); ?>
<?php echo $this->addCss('//maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css', true); ?>
<?php echo $this->addCss('//cdnjs.cloudflare.com/ajax/libs/Ladda/1.0.6/ladda.min.css', true); ?>
<?php echo $this->addJs('//cdnjs.cloudflare.com/ajax/libs/Ladda/1.0.6/spin.min.js', true); ?>
<?php echo $this->addJs('//cdnjs.cloudflare.com/ajax/libs/Ladda/1.0.6/ladda.min.js', true); ?>
<style>



    .container > .switch {
        display: block;
        margin: 12px auto;
    }

    .switch {
        position: relative;
        display: inline-block;
        vertical-align: top;
        width: 56px;
        height: 20px;
        padding: 3px;
        background-color: white;
        border-radius: 18px;
        box-shadow: inset 0 -1px white, inset 0 1px 1px rgba(0, 0, 0, 0.05);
        cursor: pointer;
        background-image: -webkit-linear-gradient(top, #eeeeee, white 25px);
        background-image: -moz-linear-gradient(top, #eeeeee, white 25px);
        background-image: -o-linear-gradient(top, #eeeeee, white 25px);
        background-image: linear-gradient(to bottom, #eeeeee, white 25px);
    }

    .switch-input {
        position: absolute;
        top: 0;
        left: 0;
        opacity: 0;
    }

    .switch-label {
        position: relative;
        display: block;
        height: inherit;
        font-size: 10px;
        text-transform: uppercase;
        background: #eceeef;
        border-radius: inherit;
        box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.12), inset 0 0 2px rgba(0, 0, 0, 0.15);
        -webkit-transition: 0.15s ease-out;
        -moz-transition: 0.15s ease-out;
        -o-transition: 0.15s ease-out;
        transition: 0.15s ease-out;
        -webkit-transition-property: opacity background;
        -moz-transition-property: opacity background;
        -o-transition-property: opacity background;
        transition-property: opacity background;
    }
    .switch-label:before, .switch-label:after {
        position: absolute;
        top: 50%;
        margin-top: -.5em;
        line-height: 1;
        -webkit-transition: inherit;
        -moz-transition: inherit;
        -o-transition: inherit;
        transition: inherit;
    }
    .switch-label:before {
        content: attr(data-off);
        right: 11px;
        color: #aaa;
        text-shadow: 0 1px rgba(255, 255, 255, 0.5);
    }
    .switch-label:after {
        content: attr(data-on);
        left: 11px;
        color: white;
        text-shadow: 0 1px rgba(0, 0, 0, 0.2);
        opacity: 0;
    }
    .switch-input:checked ~ .switch-label {
        background: #47a8d8;
        box-shadow: inset 0 1px 2px rgba(0, 0, 0, 0.15), inset 0 0 3px rgba(0, 0, 0, 0.2);
    }
    .switch-input:checked ~ .switch-label:before {
        opacity: 0;
    }
    .switch-input:checked ~ .switch-label:after {
        opacity: 1;
    }

    .switch-handle {
        position: absolute;
        top: 4px;
        left: 4px;
        width: 18px;
        height: 18px;
        background: white;
        border-radius: 10px;
        box-shadow: 1px 1px 5px rgba(0, 0, 0, 0.2);
        background-image: -webkit-linear-gradient(top, white 40%, #f0f0f0);
        background-image: -moz-linear-gradient(top, white 40%, #f0f0f0);
        background-image: -o-linear-gradient(top, white 40%, #f0f0f0);
        background-image: linear-gradient(to bottom, white 40%, #f0f0f0);
        -webkit-transition: left 0.15s ease-out;
        -moz-transition: left 0.15s ease-out;
        -o-transition: left 0.15s ease-out;
        transition: left 0.15s ease-out;
    }
    .switch-handle:before {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        margin: -6px 0 0 -6px;
        width: 12px;
        height: 12px;
        background: #f9f9f9;
        border-radius: 6px;
        box-shadow: inset 0 1px rgba(0, 0, 0, 0.02);
        background-image: -webkit-linear-gradient(top, #eeeeee, white);
        background-image: -moz-linear-gradient(top, #eeeeee, white);
        background-image: -o-linear-gradient(top, #eeeeee, white);
        background-image: linear-gradient(to bottom, #eeeeee, white);
    }
    .switch-input:checked ~ .switch-handle {
        left: 40px;
        box-shadow: -1px 1px 5px rgba(0, 0, 0, 0.2);
    }

    .switch-green > .switch-input:checked ~ .switch-label {
        background: #4fb845;
    }

</style>
<?php if ( ! class_exists( 'WooCommerce' ) ) { ?>
    <div class="hybridWooPluginSettings">
    <h2>Please activate WooCommerce </h2>
    </div>
<?php } else { ?>
<div class="hybridWooPluginSettings">
    <h2>Settings</h2>
    <form class="settingsForm">
        <?php
        settings_fields('hybridWooSettings-group');
        do_settings_sections('hybridWooSettings-group');
        ?>
        <div class="eachField">
            <label>Api endpoint</label>
            <div class="inputHolder flex">
                <input placeholder="API endpoint" type="text" name="hybridwoo_api_endpoint"
                       value="<?php echo esc_attr(get_option('hybridwoo_api_endpoint')); ?>">
            </div>
        </div>
        <div class="eachField">
            <label>API Token</label>
            <div class="inputHolder flex">
                <input placeholder="API token" type="text" name="hybridwoo_api_token"
                       value="<?php echo esc_attr(get_option('hybridwoo_api_token')); ?>">
            </div>
        </div>
        <div class="eachField">
            <label>Discount Price(%)</label>
            <div class="inputHolder flex">
                <input placeholder="Discount Price" type="text" name="hybridwoo_discount_price"
                       value="<?php echo esc_attr(get_option('hybridwoo_discount_price')); ?>">
            </div>
        </div>
        <table class="form-table" role="presentation">
            <tbody>
            <tr>
                <th scope="row"><label for="default_post_format">Registration type</label></th>
                <td>
                    <select name="hybridwoo_wp_mlm_reg_option">
                        <option value="wc_to_mlm" <?php echo (get_option('hybridwoo_wp_mlm_reg_option')=='wc_to_mlm')?'selected':false; ?>>WOOCOMMERCE->MLM</option>
                        <option value="mlm_to_wc" <?php echo (get_option('hybridwoo_wp_mlm_reg_option')=='mlm_to_wc')?'selected':false; ?>>MLM->WOOCOMMERCE</option>
                    </select>
                </td>
            </tr>

            </tbody></table>
        <div id="to-mlm-settings">
            <div class="eachField">
                <label><h3>Short Code</h3></label>
                <div class="inputHolder flex">
                    <input type="text" readonly value="[hybridwoobridge_registration_form]" id="shortcodeInput">
                    <button onclick="copy_shortcode()">Copy</button>
                </div>
            </div>
            <table class="form-table" role="presentation">
                <tbody>
                <tr>
                    <th scope="row"><label for="default_post_format">Account Create On Checkout Page</label></th>
                    <td>
                        <label class="switch">
                            <input type="checkbox" name="mlm_checkoutpage_registration" class="switch-input">
                            <span class="switch-label" data-on="On" data-off="Off"></span>
                            <span class="switch-handle"></span>
                        </label>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>

        <div class="actions">
            <button class="saveSettings btn btn-success ladda-button" data-style="contract" type="button">
                save
            </button>
        </div>
    </form>



    <div class="successMessage">
        <i class="las la-check"></i> Information saved
    </div>
</div>
<?php } ?>
<script type="text/javascript">
    jQuery(function ($) {
        Ladda.bind('.ladda-button');

        $('.saveSettings').click(function () {

            $.post('<?php echo admin_url('options.php'); ?>', $('.hybridWooPluginSettings form').serialize(), function (response) {
                $('.successMessage').slideDown();

                setTimeout(() => {
                    $('.successMessage').slideUp();
                }, 2000);
                Ladda.stopAll();
            }).fail(response => {
                Ladda.stopAll();
            });
        });
        $('[name="hybridwoo_wp_mlm_reg_option"]').change(function(){

            var selecteditem = $(this).children("option:selected").val();
            if(selecteditem=='wc_to_mlm'){
                $("#to-mlm-settings").show();
            }else{
                $("#to-mlm-settings").hide();
            }

        });
        <?php if(get_option('hybridwoo_wp_mlm_reg_option')!='wc_to_mlm'){ ?>
        $("#to-mlm-settings").hide();
        <?php } ?>
    });
    function copy_shortcode() {
        /* Get the text field */
        var copyText = document.getElementById("shortcodeInput");
        /* Select the text field */
        copyText.select();
        /* Copy the text inside the text field */
        document.execCommand("copy");
        copyText.blur();
    }
</script>