var user_name_valid=false;
var user_email_valid=false;

    jQuery(function ($) {






});

    jQuery(document).ready(function($){

        $('[name="is_affiliate"]').click(function () {
            if ($(this).prop('checked')) {

                if($("#registerform").valid()&&user_name_valid&&user_email_valid) {
                    $('[name="registerform"]').children().hide();
                    $('.hybridCustomRegistrationFields').show();
                    $('.sponsorField').slideDown();

                }else{
                    $(this).prop("checked", false);
                    if(!user_name_valid){
                        $('#user-already-exist').html('User name already exist !');
                    }
                    if(!user_email_valid){
                        $('#email-already-exist').html('Email already exist !');
                    }
                }

            } else {
                $('[name="registerform"]').children().show();
                $('.sponsorField').slideUp();
            }
        });


    //country-state
    $(function(){
        $("#country").on('change', function(){
            var coutry_id=this.value;
            get_states(coutry_id);
        })

    });
    function get_states(coutry_id) {
    $("#state").html('<option value="">Select a state</option>')
    $.ajax({
    type: 'POST',
    url: my_ajax_object.ajax_url,
    dataType: "json", // add data type
    data: {action: 'get_states_by_country', country_id: coutry_id},
    success: function (response) {

    $.each(response, function (key, value) {
    // console.log(value.id, value.name); // that's the posts data.
    $("#state").append('<option value="'+value.id+'">'+ value.name +'</option>')
});

}
});
}

    //end country-state

    var form = $("#backoffice-form");
    var sponsor_name_valid=false;

    form.steps({
    headerTag: "h6",
    bodyTag: "section",
    transitionEffect: "fade",
    titleTemplate: '<span class="step">#index#</span> #title#',
    onStepChanging: function (event, currentIndex, newIndex)
{
    if(currentIndex==0){
        if(!sponsor_name_valid) {
            $('#sponsor-error').html('Invalid sponsor name !');
        }
    return sponsor_name_valid;
}
    return $('[name="registerform"]').valid();
},
    onFinishing: function (event, currentIndex)
{
    return $('[name="registerform"]').valid();
},
    onFinished: function (event, currentIndex) {$('[name="registerform"]').submit();},

});

    /*user name checking*/
    $('[name="user_login"]').after('<label id="user-already-exist" class="error-c" for="user_email"></label>');
    $('[name="user_login"]').change(function(){
    //$('[name="is_affiliate"]').attr("disabled", true);
    verify_user_login($(this).val());
});

    function verify_user_login(user_login) {
    $.ajax({
    type: 'POST',
    url: my_ajax_object.ajax_url,
    dataType: "json", // add data type
    data: {action: 'verify_user_login', user_login: user_login},
    success: function (response) {
    if(response=="ok"){
    $('#user-already-exist').html('');
    //$('[name="is_affiliate"]').attr("disabled", false);
        user_name_valid=true;
}else{
        user_name_valid=false;
    //$('#user-already-exist').html('User name already exist !');
}

}
});
}

    /*user email checking*/
    $('[name="user_email"]').after('<label id="email-already-exist" class="error-c" for="user_email"></label>');
    $('[name="user_email"]').change(function(){
    //$('[name="is_affiliate"]').attr("disabled", true);
    verify_user_email($(this).val());
});

    function verify_user_email(user_email) {
    $.ajax({
    type: 'POST',
    url: my_ajax_object.ajax_url,
    dataType: "json", // add data type
    data: {action: 'verify_user_email', user_email: user_email},
    success: function (response) {
    if(response=="ok"){
    $('#email-already-exist').html('');
    //$('[name="is_affiliate"]').attr("disabled", false);
        user_email_valid=true;
}else{
        user_email_valid=false;
    //$('#email-already-exist').html('Email already exist !');
}

}
});
}

    /*sponsor name checking*/
    $('[name="sponsor"]').after('<label id="sponsor-error" class="error-c" for="user_email"></label>');
    $('[name="sponsor"]').change(function(){
    //$('.next').attr("disabled", true);
    $('.icon-container').show();
    verify_sponsor($(this).val());
});

    function verify_sponsor(sponsor) {
    $.ajax({
    type: 'POST',
    url: my_ajax_object.ajax_url,
    dataType: "json", // add data type
    data: {action: 'verify_sponsor', sponsor: sponsor},
    success: function (response) {
    $('.icon-container').hide();
    if(response=="ok"){
    $('#sponsor-error').html('');
    // $('.next').attr("disabled", false);
    sponsor_name_valid=true;
}else{
    $('#sponsor-error').html('Invalid sponsor name !');
    sponsor_name_valid=false;
}

}
});
}


    $('[name="registerform"]').validate({
    rules: {
    user_login: {
    required:true,
},
    user_password: {
    required: true,
    minlength: 6
},
    user_confirm_password : {
    minlength : 6,
    equalTo : "#user_password"
},
    user_email:{
    email: true,
    required:true,

},
    sponsor:{
    required:true
},
    first_name:{
    required:true
},
    last_name:{
    required:true
},
    dob:{
    required:true
},
    phone:{
    required:true
},
    gender:{
    required:true
},
    country:{
    required:true
},
    state:{
    required:true
},
    city:{
    required:true
},
    pin_code:{
    required:true
}


},
    messages: {
    user_login:{
    required: "Please enter your User Name",
    validate_user_login:"User name already exist"
},
    user_password: {
    required: "Please provide a password",
    minlength: "Your password must be at least 6 characters long"
},
    user_email: {
    email:"Please enter valid email",
    required:"Please enter your email"
},
    sponsor:{
    required:"Please enter valid sponsor name !"
},
    user_confirm_password: {
    equalTo:"Password miss match !"
}

},
    errorPlacement: function(error, element)
{

    if ( element.is(":radio")||element.attr("id")=='phone')
{
    error.appendTo( element.parents('.form-row-custom') );
}
    else
{ // This is the default behavior
    error.insertAfter( element );
}
},
    //submitHandler: function(form) {
    //    form.submit();
    //}

});



// Code goes here
//phon number
    $("#phone").intlTelInput({
    utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/12.1.6/js/utils.js"
});
});

