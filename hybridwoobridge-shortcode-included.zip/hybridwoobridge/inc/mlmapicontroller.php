<?php

namespace HybridWoo\Inc;

/**
 * Class hooks
 */
class MlmApiController
{
    /**
     * @return $this
     */
    function __construct()
    {
        $this->register_api_enpoint_urls();
        return $this;
    }

    /**
     * @param $token
     * @return bool
     */
    function validateToken($token)
    {
        $flag = $token == get_option('hybridwoo_api_token') ? true : false;
        if(!$flag){
            $response['code']=400;
            $response['error'][]="in valid api token !";
            exit(json_encode($response));
        }
        return $this;

    }


    /**
     * @return $this
     */
    function register_api_enpoint_urls()
    {
        add_action('rest_api_init', function () {
            register_rest_route('hybridwoobridge', 'mlm-register', array(
                'methods' => 'POST',
                'callback' => [$this, 'hybridwoobridge_registration']
            ));
        });
        return $this;
    }

    /**
     * @param $request
     */
    function hybridwoobridge_registration($request){
        $response = array();
        $parameters = $request->get_params();

        $this->validateToken($parameters['api_key']);
        $username = sanitize_text_field($parameters['username']);
        $email = sanitize_text_field($parameters['email']);
        $password = sanitize_text_field($parameters['password']);
        $role = isset($parameters['role'])?sanitize_text_field($parameters['role']):false;

        if (empty($username)) {
            $response['code']=406;
            $response['error'][] = __("Username field 'username' is required.");
            exit(json_encode($response));
        }
        if (empty($email)) {
            $response['code']=406;
            $response['error'][] =  __("Email field 'email' is required.");
            exit(json_encode($response));
        }
        if (empty($password)) {
            $response['code']=406;
            $response['error'][]= __("Password field 'password' is required.");
            exit(json_encode($response));
        }
        if (empty($role)) {
            // WooCommerce specific code
            if (class_exists('WooCommerce')) {
                $role = 'customer';
            } else {
                $role = 'subscriber';
            }
        } else {
            if ($GLOBALS['wp_roles']->is_role($role)) {
                if ($role == 'administrator' || $role == 'editor' || $role == 'author') {
                    $response['code']=406;
                    $response['error'][]= __("Role field 'role' is not a permitted. Only 'contributor', 'subscriber' and your custom roles are allowed.");
                    exit(json_encode($response));
                } else {
                    // Silence is gold
                }
            } else {
                $response['code']=406;
                $response['error'][]= __("Role field 'role' is not a valid. Check your User Roles from Dashboard.");
                exit(json_encode($response));
            }
        }

        $user_id = username_exists($username);
        if (!$user_id && email_exists($email) == false) {
            $user_id = wp_create_user($username, $password, $email);
            if (!is_wp_error($user_id)) {
                // Ger User Meta Data (Sensitive, Password included. DO NOT pass to front end.)
                $user = get_user_by('id', $user_id);

                //set user role
                $user->set_role($role);

                //update user meta
                $this->updateUserMetaDataDetails($user_id,$parameters);
                // Ger User Data (Non-Sensitive, Pass to front end.)
                $response['code'] = 200;
                $response['user_id'] =$user_id;
                $response['message'] = "User '" . $username . "' Registration was Successful";
            } else {
                $response['code'] = 300;
                $response['user_id'] =$user_id;
                $response['message'] = "User '" . $username . "' Registration was Successful with warning";
            }
        } else {
            $response['code']=406;
            $response['error'][] = "Email already exists, please try 'Reset Password'";

        }
        exit(json_encode($response));
    }

    /**
     * @param $user_id
     * @param $parameters
     */
    function updateUserMetaDataDetails($user_id, $parameters){
        $isAffiliate = (isset($parameters['is_affiliate'])) ? true : false;
        $sponsor = (isset($parameters['sponsor'])) ? $parameters['sponsor'] : false;
        $mlmuserid = (isset($parameters['mlmuserid'])) ? $parameters['mlmuserid'] : false;
        $first_name = (isset($parameters['first_name'])) ? $parameters['first_name'] : false;
        $last_name = (isset($parameters['last_name'])) ? $parameters['last_name'] : false;
        $dob = (isset($parameters['dob'])) ? $parameters['dob'] : false;
        $country = (isset($parameters['country'])) ? $parameters['country'] : false;
        $state = (isset($parameters['state'])) ? $parameters['state'] : false;
        $city = (isset($parameters['city'])) ? $parameters['city'] : false;
        $gender = (isset($parameters['gender'])) ? $parameters['gender'] : false;
        $pin_code = (isset($parameters['pin_code'])) ? $parameters['pin_code'] : false;
        $phone = (isset($parameters['phone'])) ? $parameters['phone'] : false;

        update_user_meta($user_id, 'is_affiliate', sanitize_text_field($isAffiliate));
        update_user_meta($user_id, 'sponsor', sanitize_text_field($sponsor));
        update_user_meta($user_id, 'first_name', sanitize_text_field($first_name));
        update_user_meta($user_id, 'last_name', sanitize_text_field($last_name));
        update_user_meta($user_id, 'dob', sanitize_text_field($dob));
        update_user_meta($user_id, 'country', sanitize_text_field($country));
        update_user_meta($user_id, 'state', sanitize_text_field($state));
        update_user_meta($user_id, 'city', sanitize_text_field($city));
        update_user_meta($user_id, 'gender', sanitize_text_field($gender));
        update_user_meta($user_id, 'pin_code', sanitize_text_field($pin_code));
        update_user_meta($user_id, 'phone', sanitize_text_field($phone));
        update_user_meta($user_id, 'mlmuserid', sanitize_text_field($mlmuserid));
    }

}
