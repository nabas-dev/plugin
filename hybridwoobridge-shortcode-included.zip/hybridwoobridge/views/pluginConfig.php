<?php echo $this->addCss('pluginConfig'); ?>
<?php echo $this->addCss('//maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css', true); ?>
<?php echo $this->addCss('//cdnjs.cloudflare.com/ajax/libs/Ladda/1.0.6/ladda.min.css', true); ?>
<?php echo $this->addJs('//cdnjs.cloudflare.com/ajax/libs/Ladda/1.0.6/spin.min.js', true); ?>
<?php echo $this->addJs('//cdnjs.cloudflare.com/ajax/libs/Ladda/1.0.6/ladda.min.js', true); ?>
<div class="hybridWooPluginSettings">
    <h2>Settings</h2>
    <form class="settingsForm">
        <?php
        settings_fields('hybridWooSettings-group');
        do_settings_sections('hybridWooSettings-group');
        ?>
        <div class="eachField">
            <label>Api endpoint</label>
            <div class="inputHolder flex">
                <input placeholder="API endpoint" type="text" name="hybridwoo_api_endpoint"
                       value="<?php echo esc_attr(get_option('hybridwoo_api_endpoint')); ?>">
            </div>
        </div>
        <div class="eachField">
            <label>API Token</label>
            <div class="inputHolder flex">
                <input placeholder="API token" type="text" name="hybridwoo_api_token"
                       value="<?php echo esc_attr(get_option('hybridwoo_api_token')); ?>">
            </div>
        </div>
        <table class="form-table" role="presentation">
            <tbody>
            <tr>
                <th scope="row"><label for="default_post_format">Registration type</label></th>
                <td>
                    <select name="hybridwoo_wp_mlm_reg_option">
                        <option value="wp_to_mlm" <?php echo (get_option('hybridwoo_wp_mlm_reg_option')=='wp_to_mlm')?'selected':false; ?>>WORDPRESS->MLM</option>
                        <option value="mlm_to_wp" <?php echo (get_option('hybridwoo_wp_mlm_reg_option')=='mlm_to_wp')?'selected':false; ?>>MLM->WORDPRESS</option>
                        <option value="wc_to_mlm" <?php echo (get_option('hybridwoo_wp_mlm_reg_option')=='wc_to_mlm')?'selected':false; ?>>WOOCOMMERCE->MLM</option>
                    </select>
                </td>
            </tr>

            </tbody></table>

        <div class="actions">
            <button class="saveSettings btn btn-success ladda-button" data-style="contract" type="button">
                save
            </button>
        </div>
    </form>
    <div class="successMessage">
        <i class="las la-check"></i> Information saved
    </div>
</div>
<script type="text/javascript">
    jQuery(function ($) {
        Ladda.bind('.ladda-button');

        $('.saveSettings').click(function () {
            $.post('<?php echo admin_url('options.php'); ?>', $('.hybridWooPluginSettings form').serialize(), function (response) {
                $('.successMessage').slideDown();

                setTimeout(() => {
                    $('.successMessage').slideUp();
                }, 2000);
                Ladda.stopAll();
            }).fail(response => {
                Ladda.stopAll();
            });
        });
    });
</script>