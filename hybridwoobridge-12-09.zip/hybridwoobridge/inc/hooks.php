<?php

namespace HybridWoo\Inc;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use Psr\Http\Message\ResponseInterface;

/**
 * Class hooks
 */
class hooks
{
    /**
     * @return $this
     */
    function __construct()
    {

        $this->adminHooks()->registration()->wooCommerceHooks()->ajax_requests();

        return $this;
    }

    /**
     * @return $this
     */
    function wooCommerceHooks()
    {
        if(get_option('hybridwoo_wp_mlm_reg_option')=="wc_to_mlm") {
            add_action('user_register', [$this, 'customerRegisterToMLM']);
            add_action('woocommerce_thankyou', [$this, 'sendOrderData'], 10, 1);
            add_action('woocommerce_checkout_before_customer_details', [$this, 'custom_checkout_fields_before_billing_details'], 20);
            // Custom checkout fields validation
            add_action('woocommerce_checkout_process', [$this, 'custom_checkout_field_process']);
            // Save custom checkout fields the data to the order
            add_action('woocommerce_checkout_create_order', [$this, 'custom_checkout_field_update_meta'], 10, 2);
        }
        return $this;
    }

    function custom_checkout_fields_before_billing_details(){
        return $this->view('WoocommerceRegistrationFields');
    }


    function custom_checkout_field_process() {
        if ( isset($_POST['sponsor']) && empty($_POST['sponsor']) )
            wc_add_notice( __( 'Please fill in "sponsor name".' ), 'error' );
    }


    function custom_checkout_field_update_meta( $order, $data ){

    }

    function customerRegisterToMLM( $user_id ) {

            $isAffiliate = (isset($_POST['is_affiliate'])) ? true : false;
            $sponsor = (isset($_POST['sponsor'])) ? $_POST['sponsor'] : false;
            $password=(isset($_POST['account_password'])) ?sanitize_text_field($_POST['account_password']):123456;


            update_user_meta($user_id, 'is_affiliate', sanitize_text_field($isAffiliate));
            update_user_meta($user_id, 'sponsor', sanitize_text_field($sponsor));




        $this->WCSendRegistrationData($user_id,$password);
        return $this;
    }

    function WCSendRegistrationData($userId,$password)
    {

        $client = $this->getAPIClient();
        $user = get_user_by('id', $userId);
        return $client->request('post', '', [
            'form_params' => [
                'action' => 'register',
                'data' => [
                    'username' => $user->user_login,
                    'email' => $user->user_email,
                    'sponsor' => get_user_meta($userId, 'sponsor', true),
                    'firstname' => get_user_meta($userId, 'billing_first_name', true),
                    'lastname' => get_user_meta($userId, 'billing_last_name', true),
                    'dob' => get_user_meta($userId, 'dob', true),
                    'country_id' => get_user_meta($userId, 'billing_country', true),
                    'state_id' => get_user_meta($userId, 'billing_state', true),
                    'city_id' => get_user_meta($userId, 'billing_city', true),
                    'gender' => get_user_meta($userId, 'gender', true),
                    'pin_code' => get_user_meta($userId, 'billing_postcode', true),
                    'phone' => get_user_meta($userId, 'phone', true),
                    'password' => $password,
                    'woo_customer_id' => $userId
                ]
            ]
        ]);
    }

    /**
     * @return $this
     */
    function ajax_requests(){
        add_action('wp_ajax_get_states_by_country', [$this, 'get_states_by_country']);
        add_action('wp_ajax_nopriv_get_states_by_country', [$this, 'get_states_by_country']);

        add_action('wp_ajax_verify_user_login', [$this, 'verifyUserName_ajax']);
        add_action('wp_ajax_nopriv_verify_user_login', [$this, 'verifyUserName_ajax']);

        add_action('wp_ajax_verify_user_email', [$this, 'verifyUserEmail_ajax']);
        add_action('wp_ajax_nopriv_verify_user_email', [$this, 'verifyUserEmail_ajax']);

        add_action('wp_ajax_verify_sponsor', [$this, 'verifySponsor_ajax']);
        add_action('wp_ajax_nopriv_verify_sponsor', [$this, 'verifySponsor_ajax']);


        return $this;
    }
    /**
     * @return ResponseInterface
     */
    function get_states_by_country(){
        $country_id = (isset($_POST['country_id'])) ? $_POST['country_id'] : false;
        $states=$this->getStates($country_id);
        exit(json_encode($states));
    }

    /**
     * @return $this
     */
    function registration()
    {
        add_action( 'login_enqueue_scripts', [$this,'enqueueStyles'] );
        if(get_option('hybridwoo_wp_mlm_reg_option')=="wp_to_mlm") {
            $isAffiliate = (isset($_POST['is_affiliate'])) ? true : false;
            add_action('register_form', [$this, 'customRegistrationFields']);
            add_filter('random_password', [$this, 'addUserPassword'], 10, 4);
            if ($isAffiliate) {
                add_action('user_register', [$this, 'processCustomRegistrationFields']);
                add_filter('registration_errors', [$this, 'validateRegistrationFields'], 10, 3);
            }
        }
        return $this;
    }
    /**
     * @return $this
     */
    function adminHooks()
    {
        if (is_admin()) {
            add_action('admin_menu', [$this, 'pluginConfig']);
            add_action('admin_init', [$this, 'registerSettings']);
        }

        return $this;
    }

    /**
     * @return $this
     */
    function enqueueStyles()
    {

        if ($GLOBALS['pagenow'] === 'wp-login.php') {
            wp_enqueue_style('bootstrap-css', '//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/css/bootstrap.min.css');
            wp_enqueue_style('telinput-css', '//cdnjs.cloudflare.com/ajax/libs/intl-tel-input/12.1.6/css/intlTelInput.css');
            wp_enqueue_script('slim-js', '//code.jquery.com/jquery-3.3.1.slim.min.js', ['jquery'], null, true);
            wp_enqueue_script('propper-js', '//cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js', ['jquery'], null, true);
            wp_enqueue_script('jquery321-js', '//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js', ['jquery'], null, true);
            wp_enqueue_script('bootstrap-js', '//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js', ['jquery'], null, true);
            wp_enqueue_script('jquery-validate1192-js', '//cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.js', ['jquery'], null, false);
            wp_enqueue_script('intl-tel-input', '//cdnjs.cloudflare.com/ajax/libs/intl-tel-input/12.1.6/js/intlTelInput.min.js', ['jquery'], null, false);
            wp_enqueue_script('jquery-steps110', '//cdnjs.cloudflare.com/ajax/libs/jquery-steps/1.1.0/jquery.steps.min.js', ['jquery'], null, false);
            wp_enqueue_style('woohybrid_registration_custom_fields', $this->stylePath('registration'), ['bootstrap-css']);
            wp_enqueue_style('woohybrid_registration_form_wizard', $this->stylePath('form-wizard'), ['bootstrap-css']);


            wp_enqueue_script('hybrid-registration-script-js', $this->jsPath('registration'), ['jquery'], null, false);
            wp_localize_script( 'hybrid-registration-script-js', 'my_ajax_object',
                array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
        }

        return $this;
    }

    /**
     * @param null $file
     * @return string
     */
    function stylePath($file = null)
    {
        return HYBRIDWOOBRIDGE_ASSETS_URL . 'css/' . $file . '.css';
    }

    /**
     * @param $order_id
     * @return bool|ResponseInterface
     * @throws GuzzleException
     */
    function sendOrderData($order_id)
    {
        if (!$order_id)
            return false;

        $client = $this->getAPIClient();
        $order = wc_get_order($order_id);

        return $client->request('post', '', [
            'form_params' => [
                'action' => 'purchase',
                'data' => [
                    'orderId' => $order->get_id(),
                    'woo_customer_id' => $order->get_user_id(),
                    'currency' => $order->get_currency(),
                    'sub_total' => $order->get_subtotal(),
                    'total' => $order->get_total(),
                    'items' => $order->get_items()
                ],
            ]
        ]);
    }

    /**
     * @return Client
     */
    function getAPIClient()
    {
        return new Client([
            'base_uri' => get_option('hybridwoo_api_endpoint'),
            // You can set any number of default request options.
            'timeout' => 2.0,
        ]);
    }

    /**
     * @return $this
     */
    function registerSettings()
    {
        register_setting('hybridWooSettings-group', 'hybridwoo_api_endpoint');
        register_setting('hybridWooSettings-group', 'hybridwoo_api_token');
        register_setting('hybridWooSettings-group', 'hybridwoo_wp_mlm_reg_option');

        return $this;
    }

    /**
     * @return mixed
     */
    function customRegistrationFields()
    {
        return $this->view('registrationFields');
    }

    /**
     * @param $path
     * @param string $extension
     * @return mixed
     */
    function view($path, $extension = '.php')
    {
        $view = include HYBRIDWOOBRIDGE_VIEW_DIR . $path . $extension;

        return $view;
    }

    /**
     * @param $user_id
     * @throws GuzzleException
     */
    function processCustomRegistrationFields($user_id)
    {
        $isAffiliate = (isset($_POST['is_affiliate'])) ? true : false;
        $sponsor = (isset($_POST['sponsor'])) ? $_POST['sponsor'] : false;
        $first_name = (isset($_POST['first_name'])) ? $_POST['first_name'] : false;
        $last_name = (isset($_POST['last_name'])) ? $_POST['last_name'] : false;
        $dob = (isset($_POST['dob'])) ? $_POST['dob'] : false;
        $country = (isset($_POST['country'])) ? $_POST['country'] : false;
        $state = (isset($_POST['state'])) ? $_POST['state'] : false;
        $city = (isset($_POST['city'])) ? $_POST['city'] : false;
        $gender = (isset($_POST['gender'])) ? $_POST['gender'] : false;
        $pin_code = (isset($_POST['pin_code'])) ? $_POST['pin_code'] : false;
        $phone = (isset($_POST['phone'])) ? $_POST['phone'] : false;

        update_user_meta($user_id, 'is_affiliate', sanitize_text_field($isAffiliate));
        update_user_meta($user_id, 'sponsor', sanitize_text_field($sponsor));
        update_user_meta($user_id, 'first_name', sanitize_text_field($first_name));
        update_user_meta($user_id, 'last_name', sanitize_text_field($last_name));
        update_user_meta($user_id, 'dob', sanitize_text_field($dob));
        update_user_meta($user_id, 'country', sanitize_text_field($country));
        update_user_meta($user_id, 'state', sanitize_text_field($state));
        update_user_meta($user_id, 'city', sanitize_text_field($city));
        update_user_meta($user_id, 'gender', sanitize_text_field($gender));
        update_user_meta($user_id, 'pin_code', sanitize_text_field($pin_code));
        update_user_meta($user_id, 'phone', sanitize_text_field($phone));

        $this->sendRegistrationData($user_id);
    }

    /**
     * @param $userId
     * @return ResponseInterface
     * @throws GuzzleException
     */
    function sendRegistrationData($userId)
    {
        $client = $this->getAPIClient();
        $user = get_user_by('id', $userId);
        return $client->request('post', '', [
            'form_params' => [
                'action' => 'register',
                'data' => [
                    'username' => $user->user_login,
                    'email' => $user->user_email,
                    'sponsor' => get_user_meta($userId, 'sponsor', true),
                    'firstname' => get_user_meta($userId, 'first_name', true),
                    'lastname' => get_user_meta($userId, 'last_name', true),
                    'dob' => get_user_meta($userId, 'dob', true),
                    'country_id' => get_user_meta($userId, 'country', true),
                    'state_id' => get_user_meta($userId, 'state', true),
                    'city_id' => get_user_meta($userId, 'city', true),
                    'gender' => get_user_meta($userId, 'gender', true),
                    'pin_code' => get_user_meta($userId, 'pin_code', true),
                    'phone' => get_user_meta($userId, 'phone', true),
                    'password' => sanitize_text_field($_POST['user_password']),
                    'woo_customer_id' => $userId
                ]
            ]
        ]);
    }
    /**
     * @param $pass
     * @param $length
     * @param $special_chars
     * @param $extra_special_chars
     * @return string
     */
    function addUserPassword($pass,$length,$special_chars,$extra_special_chars){
        if(isset($_POST['user_password'])){
            return sanitize_text_field($_POST['user_password']);
        }
        return $pass;
    }

    /**
     * @param $errors
     * @param $sanitized_user_login
     * @param $user_email
     * @return mixed
     */
    function validateRegistrationFields($errors, $sanitized_user_login, $user_email)
    {
        if ($this->verifyUsername($_POST['user_login'])) {
            $errors->add('username', 'The username seems to be exist !!');
        }

        if ($this->verifyEmail($_POST['user_email'])) {
            $errors->add('email', 'The email seems to be taken or not valid !');
        }

        if (!$this->verifySponsor($_POST['sponsor'])) {
            $errors->add('sponsor', 'This sponsor does not exist !');
        }
        if (!$this->verifyUserPassword($_POST['user_password'])) {
            $errors->add('sponsor', 'Password required !');
        }
        if (!$this->verifyUserDetails('first_name','text')) {
            $errors->add('first_name', 'First name required !');
        }
        if (!$this->verifyUserDetails('last_name','text')) {
            $errors->add('first_name', 'Last name required !');
        }
        if (!$this->verifyUserDetails('dob','date')) {
            $errors->add('first_name', 'Date of birth required !');
        }
        if (!$this->verifyUserDetails('country','select')) {
            $errors->add('first_name', 'Select a country !');
        }
        if (!$this->verifyUserDetails('state','select')) {
            $errors->add('first_name', 'Select a state !');
        }
        if (!$this->verifyUserDetails('city','select')) {
            $errors->add('first_name', 'City is required !');
        }
        if (!$this->verifyUserDetails('gender','select')) {
            $errors->add('gender', 'Select gender !');
        }
        if (!$this->verifyUserDetails('pin_code','text')) {
            $errors->add('pin_code', 'Pin code is required !');
        }
        if (!$this->verifyUserDetails('phone','text')) {
            $errors->add('pin_code', 'phone is required !');
        }

        return $errors;
    }

    /**
     * @param $default
     * @return ResponseInterface
     * @throws GuzzleException
     */
    function getCountries($default='')
    {
        $client = $this->getAPIClient();

        $result = $client->request('post', '', [
            'form_params' => [
                'action' => 'getCountries',
                'data' => [
                    'default' => $default
                ],
            ]
        ])->getBody()->getContents();

        return json_decode($result,true);
    }
    /**
     * @param $default
     * @return ResponseInterface
     * @throws GuzzleException
     */
    function getStates($default=1)
    {
        $client = $this->getAPIClient();

        $result = $client->request('post', '', [
            'form_params' => [
                'action' => 'getStates',
                'data' => [
                    'default' => $default
                ],
            ]
        ])->getBody()->getContents();

        return json_decode($result,true);
    }

    function getUserMetaDataMLM($user_name,$met_key)
    {
        $client = $this->getAPIClient();

        $result = $client->request('post', '', [
            'form_params' => [
                'action' => 'getUserMetaData',
                'username' => $user_name,
                'met_key' => $met_key
            ]
        ])->getBody()->getContents();

        exit( $result);
    }

    /**
     * @param $username
     * @return ResponseInterface
     * @throws GuzzleException
     */
    function verifyUsername($username)
    {
        $client = $this->getAPIClient();

        $result = $client->request('post', '', [
            'form_params' => [
                'action' => 'verifyUsername',
                'data' => [
                    'username' => $username
                ],
            ]
        ])->getBody()->getContents();

        return json_decode($result, true)['status'];
    }

    /**
     * @param user_login
     * @return string
     */
    function verifyUserName_ajax()
    {
        $user_name=isset($_POST['user_login'])?sanitize_text_field($_POST['user_login']):false;
        if($user_name){
            if($this->verifyUsername($user_name)){
                exit(json_encode(false));
            }else{
                exit(json_encode("ok"));
            }

        }else{
            exit(json_encode(false));
        }
        exit(json_encode(false));
    }



    /**
     * @param $email
     * @return ResponseInterface
     * @throws GuzzleException
     */
    function verifyEmail($email)
    {
        $client = $this->getAPIClient();

        $result = $client->request('post', '', [
            'form_params' => [
                'action' => 'verifyEmail',
                'data' => [
                    'email' => $email
                ],
            ]
        ])->getBody()->getContents();

        return json_decode($result, true)['status'];
    }

    /**
     * @param $_POST['user_email']
     * @return boolean
     */
    function verifyUserEmail_ajax()
    {
        $user_email=isset($_POST['user_email'])?sanitize_text_field($_POST['user_email']):false;
        if($user_email){
            if($this->verifyEmail($user_email)){
                exit(json_encode(false));
            }else{
                exit(json_encode("ok"));
            }

        }else{
            exit(json_encode(false));
        }

    }
    /**
     * @param $_POST['sponsor']
     * @return boolean
     */
    function verifySponsor_ajax()
    {
        $sponsor=isset($_POST['sponsor'])?sanitize_text_field($_POST['sponsor']):false;
        if($sponsor){
            if($this->verifySponsor($sponsor)){
                exit(json_encode("ok"));

            }else{
                exit(json_encode(false));
            }

        }else{
            exit(json_encode(false));
        }

    }

    /**
     * @param $sponsor
     * @throws GuzzleException
     */
    function verifySponsor($sponsor)
    {
        $client = $this->getAPIClient();

        $result = $client->request('post', '', [
            'form_params' => [
                'action' => 'verifySponsor',
                'data' => [
                    'sponsor' => $sponsor
                ],
            ]
        ])->getBody()->getContents();

        return json_decode($result, true)['status'];
    }
    /**
     * @param $password
     * @return  boolean
     */
    function verifyUserPassword($password)
    {
        return sanitize_text_field($password);
    }
    /**
     * @param $key
     * @param $input_type
     * @return  boolean
     */
    function verifyUserDetails($key,$input_type)
    {

        $flag=false;
        switch ($input_type) {
            case "date":
                //$date = explode("-", $_POST[$key]);
                //$flag = checkdate((int)$date[0], (int)$date[1], (int)$date[2]);
                $flag=true;
                break;
            case "text":
                $value=isset($_POST[$key])?$_POST[$key]:false;
                $flag=($value==false)?false:true;
                break;
            case "select":
                $value=isset($_POST[$key])?$_POST[$key]:false;
                $flag=($value==false)?false:true;
                break;
            default:
                $value=isset($_POST[$key])?$_POST[$key]:false;
                $flag=($value==0)?false:true;

        }

        return $flag;

    }

    /**
     * @param $path
     * @param bool $absolute
     * @return string
     */
    function addCss($path, $absolute = false)
    {
        return '<link rel="stylesheet" type="text/css" href="' . ($absolute ? $path : $this->stylePath($path)) . '" />';
    }

    /**
     * @param $path
     * @param bool $absolute
     * @return string
     */
    function addJs($path, $absolute = false)
    {
        return '<script type="text/javascript" src="' . ($absolute ? $path : $this->jsPath($path)) . '"></script>';
    }

    /**
     * @param null $file
     * @return string
     */
    function jsPath($file = null)
    {
        return HYBRIDWOOBRIDGE_ASSETS_URL . 'js/' . $file . '.js';
    }

    /**
     * @return $this
     */
    function pluginConfig()
    {
        add_options_page(HYBRIDWOOBRIDGE_PLUGIN_NAME, HYBRIDWOOBRIDGE_PLUGIN_NAME, 'manage_options', 'hybridwoobridge', [$this, 'pluginConfigPage'], 26);

        return $this;
    }

    /**
     * @return mixed
     */
    function pluginConfigPage()
    {
        return $this->view('pluginConfig');
    }
}