<style>
    .input-group > .intl-tel-input.allow-dropdown {
        -webkit-box-flex: 1;
        -ms-flex: 1 1 auto;
        flex: 1 1 auto;
        width: 1%;
    }
    .intl-tel-input .country-list{
        width: 565%;
    }

    .input-group > .intl-tel-input.allow-dropdown > .flag-container {
        z-index: 4;
    }

    /*
  Template Name: Monster Admin
  Author: Themedesigner
  Email: niravjoshi87@gmail.com
  File: css
  */

    .wizard-content .wizard>.steps>ul>li:after,
    .wizard-content .wizard>.steps>ul>li:before {
        content: '';
        z-index: 9;
        display: block;
        position: absolute
    }

    .wizard-content .wizard {
        width: 100%;
        overflow: hidden
    }

    .wizard-content .wizard .content {
        margin-left: 0!important
    }

    .wizard-content .wizard>.steps {
        position: relative;
        display: block;
        width: 100%
    }

    .wizard-content .wizard>.steps .current-info {
        position: absolute;
        left: -99999px
    }

    .wizard-content .wizard>.steps>ul {
        display: table;
        width: 100%;
        table-layout: fixed;
        margin: 0;
        padding: 0;
        list-style: none
    }

    .wizard-content .wizard>.steps>ul>li {
        display: table-cell;
        width: auto;
        vertical-align: top;
        text-align: center;
        position: relative
    }

    .wizard-content .wizard>.steps>ul>li a {
        position: relative;
        padding-top: 52px;
        margin-top: 20px;
        margin-bottom: 20px;
        display: block
    }

    .wizard-content .wizard>.steps>ul>li:before {
        left: 0
    }

    .wizard-content .wizard>.steps>ul>li:after {
        right: 0
    }

    .wizard-content .wizard>.steps>ul>li:first-child:before,
    .wizard-content .wizard>.steps>ul>li:last-child:after {
        content: none
    }

    .wizard-content .wizard>.steps>ul>li.current>a {
        color: #2f3d4a;
        cursor: default
    }

    .wizard-content .wizard>.steps>ul>li.current .step {
        border-color: #009efb ;
        background-color: #fff;
        color: #009efb
    }

    .wizard-content .wizard>.steps>ul>li.disabled a,
    .wizard-content .wizard>.steps>ul>li.disabled a:focus,
    .wizard-content .wizard>.steps>ul>li.disabled a:hover {
        color: #999;
        cursor: default
    }

    .wizard-content .wizard>.steps>ul>li.done a,
    .wizard-content .wizard>.steps>ul>li.done a:focus,
    .wizard-content .wizard>.steps>ul>li.done a:hover {
        color: #999
    }

    .wizard-content .wizard>.steps>ul>li.done .step {
        background-color: #009efb ;
        border-color: #009efb ;
        color: #fff
    }

    .wizard-content .wizard>.steps>ul>li.error .step {
        border-color: #f62d51;
        color: #f62d51
    }

    .wizard-content .wizard>.steps .step {
        background-color: #fff;
        display: inline-block;
        position: absolute;
        top: 0;
        left: 50%;
        margin-left: -24px;
        z-index: 10;
        text-align: center
    }

    .wizard-content .wizard>.content {
        overflow: hidden;
        position: relative;
        width: auto;
        padding: 0;
        margin: 0
    }

    .wizard-content .wizard>.content>.title {
        position: absolute;
        left: -99999px
    }

    .wizard-content .wizard>.content>.body {
        padding: 0 20px
    }

    .wizard-content .wizard>.content>iframe {
        border: 0;
        width: 100%;
        height: 100%
    }

    .wizard-content .wizard>.actions {
        position: relative;
        display: block;
        text-align: right;
        padding: 0 20px 20px
    }

    .wizard-content .wizard>.actions>ul {
        float: right;
        list-style: none;
        padding: 0;
        margin: 0
    }

    .wizard-content .wizard>.actions>ul:after {
        content: '';
        display: table;
        clear: both
    }

    .wizard-content .wizard>.actions>ul>li {
        float: left
    }

    .wizard-content .wizard>.actions>ul>li+li {
        margin-left: 10px
    }

    .wizard-content .wizard>.actions>ul>li>a {
        background: #009efb ;
        color: #fff;
        display: block;
        padding: 7px 12px;
        border-radius: 4px;
        border: 1px solid transparent
    }

    .wizard-content .wizard>.actions>ul>li>a:focus,
    .wizard-content .wizard>.actions>ul>li>a:hover {
        -webkit-box-shadow: 0 0 0 100px rgba(0, 0, 0, .05) inset;
        box-shadow: 0 0 0 100px rgba(0, 0, 0, .05) inset
    }

    .wizard-content .wizard>.actions>ul>li>a:active {
        -webkit-box-shadow: 0 0 0 100px rgba(0, 0, 0, .1) inset;
        box-shadow: 0 0 0 100px rgba(0, 0, 0, .1) inset
    }

    .wizard-content .wizard>.actions>ul>li>a[href="#previous"] {
        background-color: #fff;
        color: #54667a;
        border: 1px solid #d9d9d9
    }

    .wizard-content .wizard>.actions>ul>li>a[href="#previous"]:focus,
    .wizard-content .wizard>.actions>ul>li>a[href="#previous"]:hover {
        -webkit-box-shadow: 0 0 0 100px rgba(0, 0, 0, .02) inset;
        box-shadow: 0 0 0 100px rgba(0, 0, 0, .02) inset
    }

    .wizard-content .wizard>.actions>ul>li>a[href="#previous"]:active {
        -webkit-box-shadow: 0 0 0 100px rgba(0, 0, 0, .04) inset;
        box-shadow: 0 0 0 100px rgba(0, 0, 0, .04) inset
    }

    .wizard-content .wizard>.actions>ul>li.disabled>a,
    .wizard-content .wizard>.actions>ul>li.disabled>a:focus,
    .wizard-content .wizard>.actions>ul>li.disabled>a:hover {
        color: #999
    }

    .wizard-content .wizard>.actions>ul>li.disabled>a[href="#previous"],
    .wizard-content .wizard>.actions>ul>li.disabled>a[href="#previous"]:focus,
    .wizard-content .wizard>.actions>ul>li.disabled>a[href="#previous"]:hover {
        -webkit-box-shadow: none;
        box-shadow: none
    }

    .wizard-content .wizard.wizard-circle>.steps>ul>li:after,
    .wizard-content .wizard.wizard-circle>.steps>ul>li:before {
        top: 45px;
        width: 50%;
        height: 3px;
        background-color: #009efb
    }

    .wizard-content .wizard.wizard-circle>.steps>ul>li.current:after,
    .wizard-content .wizard.wizard-circle>.steps>ul>li.current~li:after,
    .wizard-content .wizard.wizard-circle>.steps>ul>li.current~li:before {
        background-color: #F3F3F3
    }

    .wizard-content .wizard.wizard-circle>.steps .step {
        width: 50px;
        height: 50px;
        line-height: 45px;
        border: 3px solid #F3F3F3;
        font-size: 1.3rem;
        border-radius: 50%
    }

    .wizard-content .wizard.wizard-notification>.steps>ul>li:after,
    .wizard-content .wizard.wizard-notification>.steps>ul>li:before {
        top: 39px;
        width: 50%;
        height: 2px;
        background-color: #009efb
    }

    .wizard-content .wizard.wizard-notification>.steps>ul>li.current .step {
        border: 2px solid #009efb ;
        color: #009efb ;
        line-height: 36px
    }

    .wizard-content .wizard.wizard-notification>.steps>ul>li.current .step:after,
    .wizard-content .wizard.wizard-notification>.steps>ul>li.done .step:after {
        border-top-color: #009efb
    }

    .wizard-content .wizard.wizard-notification>.steps>ul>li.current:after,
    .wizard-content .wizard.wizard-notification>.steps>ul>li.current~li:after,
    .wizard-content .wizard.wizard-notification>.steps>ul>li.current~li:before {
        background-color: #F3F3F3
    }

    .wizard-content .wizard.wizard-notification>.steps>ul>li.done .step {
        color: #FFF
    }

    .wizard-content .wizard.wizard-notification>.steps .step {
        width: 40px;
        height: 40px;
        line-height: 40px;
        font-size: 1.3rem;
        border-radius: 15%;
        background-color: #F3F3F3
    }

    .wizard-content .wizard.wizard-notification>.steps .step:after {
        content: "";
        width: 0;
        height: 0;
        position: absolute;
        bottom: 0;
        left: 50%;
        margin-left: -8px;
        margin-bottom: -8px;
        border-left: 7px solid transparent;
        border-right: 7px solid transparent;
        border-top: 8px solid #F3F3F3
    }

    .wizard-content .wizard.vertical>.steps {
        display: inline;
        float: left;
        width: 20%
    }

    .wizard-content .wizard.vertical>.steps>ul>li {
        display: block;
        width: 100%
    }

    .wizard-content .wizard.vertical>.steps>ul>li.current:after,
    .wizard-content .wizard.vertical>.steps>ul>li.current:before,
    .wizard-content .wizard.vertical>.steps>ul>li.current~li:after,
    .wizard-content .wizard.vertical>.steps>ul>li.current~li:before,
    .wizard-content .wizard.vertical>.steps>ul>li:after,
    .wizard-content .wizard.vertical>.steps>ul>li:before {
        background-color: transparent
    }

    @media (max-width:768px) {
        .wizard-content .wizard>.steps>ul {
            margin-bottom: 20px
        }
        .wizard-content .wizard>.steps>ul>li {
            display: block;
            float: left;
            width: 50%
        }
        .wizard-content .wizard>.steps>ul>li>a {
            margin-bottom: 0
        }
        .wizard-content .wizard>.steps>ul>li:first-child:before {
            content: ''
        }
        .wizard-content .wizard>.steps>ul>li:last-child:after {
            content: '';
            background-color: #009efb
        }
        .wizard-content .wizard.vertical>.steps {
            width: 15%
        }
    }

    @media (max-width:480px) {
        .wizard-content .wizard>.steps>ul>li {
            width: 100%
        }
        .wizard-content .wizard>.steps>ul>li.current:after {
            background-color: #009efb
        }
        .wizard-content .wizard.vertical>.steps>ul>li {
            display: block;
            float: left;
            width: 50%
        }
        .wizard-content .wizard.vertical>.steps {
            width: 100%;
            float:none;
        }
    }
</style>
  <p>
      <label for="user_password"><?php _e( 'Password','HybridWoo' ); ?></label>
      <input type="password" name="user_password" id="user_password" class="input" value="<?php echo $_POST['user_password']; ?>" size="25" />
  </p>
<div class="hybridCustomRegistrationFields">
    <div class="row">
        <div class="col-md-7">
            <label><?php _e( 'Register as Affiliate ?','HybridWoo' ); ?></label>
        </div>
        <div class="col-md-5">
            <div class="checkboxHolder">
                <input type="checkbox" name="is_affiliate">
            </div>
        </div>
    </div>

    <div class="container sponsorField" style="display: none">
        <div class="panel">
            <div class="panel-body wizard-content">
                <div id="example-form"  class="tab-wizard wizard-circle wizard clearfix">
                    <h6>Sponsor</h6>
                    <section>
                        <br/>
                        <div class="row">
                            <div class="col-sm-12 col-sm-push-12">

                            </div>
                        </div>
                    </section>

                    <h6>Profile</h6>
                    <section>
                        <div class="row">
                            <div class="col-sm-12">


                            </div>
                        </div>
                    </section>

                    <h6>Address</h6>
                    <section>
                        <div class="row">
                            <div class="col-sm-12">

                            </div>
                        </div>

                    </section>



                </div>
            </div>
        </div>
    </div>

    <div class="row sponsorField">
        <label><?php _e( 'Sponsor name','HybridWoo' ); ?></label>
        <input type="text" name="sponsor" placeholder="sponsor" value="<?php echo $_POST['sponsor']; ?>" size="25">
    </div>

    <div class="row sponsorField">
        <label><?php _e( 'First name','HybridWoo' ); ?></label>
        <input type="text" name="first_name" placeholder="First name" value="<?php echo $_POST['first_name']; ?>" size="25">
    </div>
    <div class="row sponsorField">
        <label><?php _e( 'Last name','HybridWoo' ); ?></label>
        <input type="text" name="last_name" placeholder="Last name" value="<?php echo $_POST['last_name']; ?>" size="25">
    </div>
    <div class="row sponsorField">
        <label><?php _e( 'Phone number','HybridWoo' ); ?></label>
        <div class="input-group input-group-sm">
            <input  name="phone" id="phone" type="tel" class="form-control form-control-sm rounded-0 w-100" value="<?php echo $_POST['phone']; ?>">
            <div class="input-group-append">
                <span class="input-group-text rounded-0 fa fa-phone"></span>
            </div>
        </div>
    </div>
    <div class="row sponsorField">
        <label><?php _e( 'Date of birth','HybridWoo' ); ?></label>
        <input type="date" name="dob" id="dob" class="form-control" value="<?php echo $_POST['dob']; ?>">
    </div>
    <div class="form-group row sponsorField">
        <label><?php _e( 'Gender','HybridWoo' ); ?></label>
        <div class="radio-list">
            <label>
                <input type="radio" checked="" name="gender" value="M" data-title="Male"> Male
            </label>
            <label>
                <input type="radio" name="gender" value="F" data-title="Female"> Female
            </label>
        </div>
    </div>
    <div class="row sponsorField">
        <label><?php _e( 'Country','HybridWoo' ); ?></label>
        <select name="country" id="country" class="form-control browser-default custom-select">
            <option value="">Select a Country</option>
            <?php $countires = $this->getCountries();
            foreach ($countires as $country){

                $country_code=$country['id'];
                $country_name=$country['name'];

                echo "<option value='$country_code'>$country_name</option>";
            }
            ?>

        </select>

    </div>
    <div class="row sponsorField">
        <label><?php _e( 'State','HybridWoo' ); ?></label>
        <select name="state" id="state" class="form-control browser-default custom-select">
            <option value="">Select a state</option>
            <?php $states = $this->getStates();
            foreach ($states as $state){

                $state_code=$state['id'];
                $state_name=$state['name'];

                echo "<option value='$state_code'>$state_name</option>";
            }
            ?>
        </select>
    </div>
    <div class="row sponsorField">
        <label><?php _e( 'City','HybridWoo' ); ?></label>
        <input type="text" name="city" placeholder="City" value="<?php echo $_POST['city']; ?>" size="25">
    </div>
    <div class="row sponsorField">
        <label><?php _e( 'Pin code','HybridWoo' ); ?></label>
        <input type="text" name="pin_code" placeholder="Pin code" value="<?php echo $_POST['pin_code']; ?>" size="25">
    </div>


</div>
<script type="text/javascript">
    jQuery(function ($) {
        $('[name="is_affiliate"]').click(function () {
            if ($(this).prop('checked')) {
                if($("#registerform").valid()) {
                    $('.sponsorField').slideDown();
                }else{
                    $(this).prop("checked", false);
                }

            } else {
                $('.sponsorField').slideUp();
            }
        });

        //country-state
        $('#country').on('change', function() {
            var coutry_id=this.value;
            get_states(coutry_id);

        });
        function get_states(coutry_id) {
            $("#state").html('<option value="">Select a state</option>')
            $.ajax({
                type: 'POST',
                url: '<?php echo admin_url('admin-ajax.php');?>',
                dataType: "json", // add data type
                data: {action: 'get_states_by_country', country_id: coutry_id},
                success: function (response) {

                    $.each(response, function (key, value) {
                       // console.log(value.id, value.name); // that's the posts data.
                        $("#state").append('<option value="'+value.id+'">'+ value.name +'</option>')
                    });

                }
            });
        }

        //end country-state




    });

    jQuery(document).ready(function($){
        var form = $("#example-form");

        form.steps({
            headerTag: "h6",
            bodyTag: "section",
            transitionEffect: "fade",
            titleTemplate: '<span class="step">#index#</span> #title#'
        });
        /*user name checking*/
        $('[name="user_login"]').after('<label id="user-already-exist" class="error-c" for="user_email"></label>');
        $('[name="user_login"]').change(function(){
            $('[name="is_affiliate"]').attr("disabled", true);
            verify_user_login($(this).val());
        });

        function verify_user_login(user_login) {
            $.ajax({
                type: 'POST',
                url: '<?php echo admin_url('admin-ajax.php');?>',
                dataType: "json", // add data type
                data: {action: 'verify_user_login', user_login: user_login},
                success: function (response) {
                    if(response=="ok"){
                        $('#user-already-exist').html('');
                        $('[name="is_affiliate"]').attr("disabled", false);
                    }else{
                        $('#user-already-exist').html('User name already exist !');
                    }

                }
            });
        }
        /*user email checking*/
        $('[name="user_email"]').after('<label id="email-already-exist" class="error-c" for="user_email"></label>');
        $('[name="user_email"]').change(function(){
            $('[name="is_affiliate"]').attr("disabled", true);
            verify_user_email($(this).val());
        });

        function verify_user_email(user_email) {
            $.ajax({
                type: 'POST',
                url: '<?php echo admin_url('admin-ajax.php');?>',
                dataType: "json", // add data type
                data: {action: 'verify_user_email', user_email: user_email},
                success: function (response) {
                    if(response=="ok"){
                        $('#email-already-exist').html('');
                        $('[name="is_affiliate"]').attr("disabled", false);
                    }else{
                        $('#email-already-exist').html('Email already exist !');
                    }

                }
            });
        }


        $("#registerform").validate({
            rules: {
                user_login: {
                    required:true,
                },
                user_password: {
                    required: true,
                    minlength: 6
                },
                user_email:{
                    email: true,
                    required:true,

                }


            },
            messages: {
                user_login:{
                    required: "Please enter your User Name",
                    validate_user_login:"User name already exist"
                },
                user_password: {
                    required: "Please provide a password",
                    minlength: "Your password must be at least 6 characters long"
                },
                user_email: {
                    email:"Please enter valid email",
                    required:"Please enter your email"
                }

            },
            errorPlacement: function(error, element)
            {
                if ( element.is(":radio") )
                {
                    error.appendTo( element.parents('.form-group') );
                }
                else
                { // This is the default behavior
                    error.insertAfter( element );
                }
            },
            //submitHandler: function(form) {
            //    form.submit();
            //}

        });



// Code goes here
//phon number
        $("#phone").intlTelInput({
            utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/12.1.6/js/utils.js"
        });
    });
</script>